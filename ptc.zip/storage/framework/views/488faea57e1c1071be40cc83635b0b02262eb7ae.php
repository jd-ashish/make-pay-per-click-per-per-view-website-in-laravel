

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/trumbowyg/ui/trumbowyg.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Global Template",array("home","Email Manager","Global Template","index"),"")); ?>

<!-- end row -->


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="far fa-file"></i> Global termpate</h3>
            </div>
            <form action="<?php echo e(route('emial.global.template.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <textarea rows="3" class="form-control editor" name="global_template"><?php echo e(App\Settings::where('var','email_global_template')->first()->val); ?></textarea>
                </div>
                <button class="btn btn-dropbox float-right" type="submit">Save template</button>
            </form>
            
        </div><!-- end card-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/plugins/trumbowyg/trumbowyg.min.js')); ?>"></script>
<script>
    $(document).on('ready',function() {
        'use strict';
        $('.editor').trumbowyg();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/email_manager/global_template.blade.php ENDPATH**/ ?>