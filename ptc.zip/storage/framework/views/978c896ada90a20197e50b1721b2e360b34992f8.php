/* default margin css start */

.my-5 {
    margin: 5px 0;
}

.my-10 {
    margin: 10px 0;
}

.my-15 {
    margin: 15px 0;
}

.my-20 {
    margin: 20px 0;
}

.my-25 {
    margin: 25px 0;
}

.my-30 {
    margin: 30px 0;
}

.my-35 {
    margin: 35px 0;
}

.my-40 {
    margin: 40px 0;
}

.my-45 {
    margin: 45px 0;
}

.my-50 {
    margin: 50px 0;
}

.my-55 {
    margin: 55px 0;
}

.my-60 {
    margin: 60px 0;
}

.my-65 {
    margin: 65px 0;
}

.my-70 {
    margin: 70px 0;
}

.my-75 {
    margin: 75px 0;
}

.my-80 {
    margin: 80px 0;
}

.my-85 {
    margin: 85px 0;
}

.my-90 {
    margin: 90px 0;
}

.my-95 {
    margin: 95px 0;
}

.my-100 {
    margin: 100px 0;
}

.mx-5 {
    margin: 0 5px;
}

.mx-10 {
    margin: 0 10px;
}

.mx-15 {
    margin: 0 15px;
}

.mx-20 {
    margin: 0 20px;
}

.mx-25 {
    margin: 0 25px;
}

.mx-30 {
    margin: 0 30px;
}

.mx-35 {
    margin: 0 35px;
}

.mx-40 {
    margin: 0 40px;
}

.mx-45 {
    margin: 0 45px;
}

.mx-50 {
    margin: 0 50px;
}

.mx-55 {
    margin: 0 55px;
}

.mx-60 {
    margin: 0 60px;
}

.mx-65 {
    margin: 0 65px;
}

.mx-70 {
    margin: 0 70px;
}

.mx-75 {
    margin: 0 75px;
}

.mx-80 {
    margin: 0 80px;
}

.mx-85 {
    margin: 0 85px;
}

.mx-90 {
    margin: 0 90px;
}

.mx-95 {
    margin: 0 95px;
}

.mx-100 {
    margin: 0 100px;
}

.mt-5 {
    margin-top: 5px;
}

.mt-10 {
    margin-top: 10px;
}

.mt-15 {
    margin-top: 15px;
}

.mt-20 {
    margin-top: 20px;
}

.mt-25 {
    margin-top: 25px;
}

.mt-30 {
    margin-top: 30px;
}

.mt-35 {
    margin-top: 35px;
}

.mt-40 {
    margin-top: 40px;
}

.mt-45 {
    margin-top: 45px;
}

.mt-50 {
    margin-top: 50px;
}

.mt-55 {
    margin-top: 55px;
}

.mt-60 {
    margin-top: 60px;
}

.mt-65 {
    margin-top: 65px;
}

.mt-70 {
    margin-top: 70px;
}

.mt-75 {
    margin-top: 75px;
}

.mt-80 {
    margin-top: 80px;
}

.mt-85 {
    margin-top: 85px;
}

.mt-90 {
    margin-top: 90px;
}

.mt-95 {
    margin-top: 95px;
}

.mt-100 {
    margin-top: 100px;
}

.mb-5 {
    margin-bottom: 5px;
}

.mb-10 {
    margin-bottom: 10px;
}

.mb-15 {
    margin-bottom: 15px;
}

.mb-20 {
    margin-bottom: 20px;
}

.mb-25 {
    margin-bottom: 25px;
}

.mb-30 {
    margin-bottom: 30px;
}

.mb-35 {
    margin-bottom: 35px;
}

.mb-40 {
    margin-bottom: 40px;
}

.mb-45 {
    margin-bottom: 45px;
}

.mb-50 {
    margin-bottom: 50px;
}

.mb-55 {
    margin-bottom: 55px;
}

.mb-60 {
    margin-bottom: 60px;
}

.mb-65 {
    margin-bottom: 65px;
}

.mb-70 {
    margin-bottom: 70px;
}

.mb-75 {
    margin-bottom: 75px;
}

.mb-80 {
    margin-bottom: 80px;
}

.mb-85 {
    margin-bottom: 85px;
}

.mb-90 {
    margin-bottom: 90px;
}

.mb-95 {
    margin-bottom: 95px;
}

.mb-100 {
    margin-bottom: 100px;
}

.ml-5 {
    margin-left: 5px;
}

.ml-10 {
    margin-left: 10px;
}

.ml-15 {
    margin-left: 15px;
}

.ml-20 {
    margin-left: 20px;
}

.ml-25 {
    margin-left: 25px;
}

.ml-30 {
    margin-left: 30px;
}

.ml-35 {
    margin-left: 35px;
}

.ml-40 {
    margin-left: 40px;
}

.ml-45 {
    margin-left: 45px;
}

.ml-50 {
    margin-left: 50px;
}

.ml-55 {
    margin-left: 55px;
}

.ml-60 {
    margin-left: 60px;
}

.ml-65 {
    margin-left: 65px;
}

.ml-70 {
    margin-left: 70px;
}

.ml-75 {
    margin-left: 75px;
}

.ml-80 {
    margin-left: 80px;
}

.ml-85 {
    margin-left: 85px;
}

.ml-90 {
    margin-left: 90px;
}

.ml-95 {
    margin-left: 95px;
}

.ml-100 {
    margin-left: 100px;
}

.mr-5 {
    margin-right: 5px;
}

.mr-10 {
    margin-right: 10px;
}

.mr-15 {
    margin-right: 15px;
}

.mr-20 {
    margin-right: 20px;
}

.mr-25 {
    margin-right: 25px;
}

.mr-30 {
    margin-right: 30px;
}

.mr-35 {
    margin-right: 35px;
}

.mr-40 {
    margin-right: 40px;
}

.mr-45 {
    margin-right: 45px;
}

.mr-50 {
    margin-right: 50px;
}

.mr-55 {
    margin-right: 55px;
}

.mr-60 {
    margin-right: 60px;
}

.mr-65 {
    margin-right: 65px;
}

.mr-70 {
    margin-right: 70px;
}

.mr-75 {
    margin-right: 75px;
}

.mr-80 {
    margin-right: 80px;
}

.mr-85 {
    margin-right: 85px;
}

.mr-90 {
    margin-right: 90px;
}

.mr-95 {
    margin-right: 95px;
}

.mr-100 {
    margin-right: 100px;
}

.my-none-5 {
    margin: -5px 0;
}

.my-none-10 {
    margin: -10px 0;
}

.my-none-15 {
    margin: -15px 0;
}

.my-none-20 {
    margin: -20px 0;
}

.my-none-25 {
    margin: -25px 0;
}

.my-none-30 {
    margin: -30px 0;
}

.my-none-35 {
    margin: -35px 0;
}

.my-none-40 {
    margin: -40px 0;
}

.my-none-45 {
    margin: -45px 0;
}

.my-none-50 {
    margin: -50px 0;
}

.mx-none-5 {
    margin: 0 -5px;
}

.mx-none-10 {
    margin: 0 -10px;
}

.mx-none-15 {
    margin: 0 -15px;
}

.mx-none-20 {
    margin: 0 -20px;
}

.mx-none-25 {
    margin: 0 -25px;
}

.mx-none-30 {
    margin: 0 -30px;
}

.mx-none-35 {
    margin: 0 -35px;
}

.mx-none-40 {
    margin: 0 -40px;
}

.mx-none-45 {
    margin: 0 -45px;
}

.mx-none-50 {
    margin: 0 -50px;
}

.mt-none-5 {
    margin-top: -5px;
}

.mt-none-10 {
    margin-top: -10px;
}

.mt-none-15 {
    margin-top: -15px;
}

.mt-none-20 {
    margin-top: -20px;
}

.mt-none-25 {
    margin-top: -25px;
}

.mt-none-30 {
    margin-top: -30px;
}

.mt-none-35 {
    margin-top: -35px;
}

.mt-none-40 {
    margin-top: -40px;
}

.mt-none-45 {
    margin-top: -45px;
}

.mt-none-50 {
    margin-top: -50px;
}

.mb-none-5 {
    margin-bottom: -5px;
}

.mb-none-10 {
    margin-bottom: -10px;
}

.mb-none-15 {
    margin-bottom: -15px;
}

.mb-none-20 {
    margin-bottom: -20px;
}

.mb-none-25 {
    margin-bottom: -25px;
}

.mb-none-30 {
    margin-bottom: -30px;
}

.mb-none-35 {
    margin-bottom: -35px;
}

.mb-none-40 {
    margin-bottom: -40px;
}

.mb-none-45 {
    margin-bottom: -45px;
}

.mb-none-50 {
    margin-bottom: -50px;
}

/* default margin css end */
/* default padding css start */
.py-5 {
    padding: 5px 0;
}

.py-10 {
    padding: 10px 0;
}

.py-15 {
    padding: 15px 0;
}

.py-20 {
    padding: 20px 0;
}

.py-25 {
    padding: 25px 0;
}

.py-30 {
    padding: 30px 0;
}

.py-35 {
    padding: 35px 0;
}

.py-40 {
    padding: 40px 0;
}

.py-45 {
    padding: 45px 0;
}

.py-50 {
    padding: 50px 0;
}

.py-55 {
    padding: 55px 0;
}

.py-60 {
    padding: 60px 0;
}

.py-65 {
    padding: 65px 0;
}

.py-70 {
    padding: 70px 0;
}

.py-75 {
    padding: 75px 0;
}

.py-80 {
    padding: 80px 0;
}

.py-85 {
    padding: 85px 0;
}

.py-90 {
    padding: 90px 0;
}

.py-95 {
    padding: 95px 0;
}

.py-100 {
    padding: 100px 0;
}

.py-105 {
    padding: 105px 0;
}

.py-110 {
    padding: 110px 0;
}

.py-115 {
    padding: 100px 0;
}

.py-120 {
    padding: 115px 0;
}

.py-125 {
    padding: 125px 0;
}

.py-130 {
    padding: 130px 0;
}

.py-135 {
    padding: 135px 0;
}

.py-140 {
    padding: 140px 0;
}

.py-145 {
    padding: 145px 0;
}

.py-150 {
    padding: 150px 0;
}

.px-5 {
    padding: 0 5px;
}

.px-10 {
    padding: 0 10px;
}

.px-15 {
    padding: 0 15px;
}

.px-20 {
    padding: 0 20px;
}

.px-25 {
    padding: 0 25px;
}

.px-30 {
    padding: 0 30px;
}

.px-35 {
    padding: 0 35px;
}

.px-40 {
    padding: 0 40px;
}

.px-45 {
    padding: 0 45px;
}

.px-50 {
    padding: 0 50px;
}

.px-55 {
    padding: 0 55px;
}

.px-60 {
    padding: 0 60px;
}

.px-65 {
    padding: 0 65px;
}

.px-70 {
    padding: 0 70px;
}

.px-75 {
    padding: 0 75px;
}

.px-80 {
    padding: 0 80px;
}

.px-85 {
    padding: 0 85px;
}

.px-90 {
    padding: 0 90px;
}

.px-95 {
    padding: 0 95px;
}

.px-100 {
    padding: 0 100px;
}

.px-105 {
    padding: 0 105px;
}

.px-110 {
    padding: 0 110px;
}

.px-115 {
    padding: 0 100px;
}

.px-120 {
    padding: 0 115px;
}

.px-125 {
    padding: 0 125px;
}

.px-130 {
    padding: 0 130px;
}

.px-135 {
    padding: 0 135px;
}

.px-140 {
    padding: 0 140px;
}

.px-145 {
    padding: 0 145px;
}

.px-150 {
    padding: 0 150px;
}

.pt-5 {
    padding-top: 5px;
}

.pt-10 {
    padding-top: 10px;
}

.pt-15 {
    padding-top: 15px;
}

.pt-20 {
    padding-top: 20px;
}

.pt-25 {
    padding-top: 25px;
}

.pt-30 {
    padding-top: 30px;
}

.pt-35 {
    padding-top: 35px;
}

.pt-40 {
    padding-top: 40px;
}

.pt-45 {
    padding-top: 45px;
}

.pt-50 {
    padding-top: 50px;
}

.pt-55 {
    padding-top: 55px;
}

.pt-60 {
    padding-top: 60px;
}

.pt-65 {
    padding-top: 65px;
}

.pt-70 {
    padding-top: 70px;
}

.pt-75 {
    padding-top: 75px;
}

.pt-80 {
    padding-top: 80px;
}

.pt-85 {
    padding-top: 85px;
}

.pt-90 {
    padding-top: 90px;
}

.pt-95 {
    padding-top: 95px;
}

.pt-100 {
    padding-top: 100px;
}

.pt-105 {
    padding-top: 105px;
}

.pt-110 {
    padding-top: 110px;
}

.pt-115 {
    padding-top: 100px;
}

.pt-120 {
    padding-top: 115px;
}

.pt-125 {
    padding-top: 125px;
}

.pt-130 {
    padding-top: 130px;
}

.pt-135 {
    padding-top: 135px;
}

.pt-140 {
    padding-top: 140px;
}

.pt-145 {
    padding-top: 145px;
}

.pt-150 {
    padding-top: 150px;
}

.pb-5 {
    padding-bottom: 5px;
}

.pb-10 {
    padding-bottom: 10px;
}

.pb-15 {
    padding-bottom: 15px;
}

.pb-20 {
    padding-bottom: 20px;
}

.pb-25 {
    padding-bottom: 25px;
}

.pb-30 {
    padding-bottom: 30px;
}

.pb-35 {
    padding-bottom: 35px;
}

.pb-40 {
    padding-bottom: 40px;
}

.pb-45 {
    padding-bottom: 45px;
}

.pb-50 {
    padding-bottom: 50px;
}

.pb-55 {
    padding-bottom: 55px;
}

.pb-60 {
    padding-bottom: 60px;
}

.pb-65 {
    padding-bottom: 65px;
}

.pb-70 {
    padding-bottom: 70px;
}

.pb-75 {
    padding-bottom: 75px;
}

.pb-80 {
    padding-bottom: 80px;
}

.pb-85 {
    padding-bottom: 85px;
}

.pb-90 {
    padding-bottom: 90px;
}

.pb-95 {
    padding-bottom: 95px;
}

.pb-100 {
    padding-bottom: 100px;
}

.pb-105 {
    padding-bottom: 105px;
}

.pb-110 {
    padding-bottom: 110px;
}

.pb-115 {
    padding-bottom: 100px;
}

.pb-120 {
    padding-bottom: 115px;
}

.pb-125 {
    padding-bottom: 125px;
}

.pb-130 {
    padding-bottom: 130px;
}

.pb-135 {
    padding-bottom: 135px;
}

.pb-140 {
    padding-bottom: 140px;
}

.pb-145 {
    padding-bottom: 145px;
}

.pb-150 {
    padding-bottom: 150px;
}

.pl-5 {
    padding-left: 5px;
}

.pl-10 {
    padding-left: 10px;
}

.pl-15 {
    padding-left: 15px;
}

.pl-20 {
    padding-left: 20px;
}

.pl-25 {
    padding-left: 25px;
}

.pl-30 {
    padding-left: 30px;
}

.pl-35 {
    padding-left: 35px;
}

.pl-40 {
    padding-left: 40px;
}

.pl-45 {
    padding-left: 45px;
}

.pl-50 {
    padding-left: 50px;
}

.pl-55 {
    padding-left: 55px;
}

.pl-60 {
    padding-left: 60px;
}

.pl-65 {
    padding-left: 65px;
}

.pl-70 {
    padding-left: 70px;
}

.pl-75 {
    padding-left: 75px;
}

.pl-80 {
    padding-left: 80px;
}

.pl-85 {
    padding-left: 85px;
}

.pl-90 {
    padding-left: 90px;
}

.pl-95 {
    padding-left: 95px;
}

.pl-100 {
    padding-left: 100px;
}

.pl-105 {
    padding-left: 105px;
}

.pl-110 {
    padding-left: 110px;
}

.pl-115 {
    padding-left: 100px;
}

.pl-120 {
    padding-left: 115px;
}

.pl-125 {
    padding-left: 125px;
}

.pl-130 {
    padding-left: 130px;
}

.pl-135 {
    padding-left: 135px;
}

.pl-140 {
    padding-left: 140px;
}

.pl-145 {
    padding-left: 145px;
}

.pl-150 {
    padding-left: 150px;
}

.pr-5 {
    padding-right: 5px;
}

.pr-10 {
    padding-right: 10px;
}

.pr-15 {
    padding-right: 15px;
}

.pr-20 {
    padding-right: 20px;
}

.pr-25 {
    padding-right: 25px;
}

.pr-30 {
    padding-right: 30px;
}

.pr-35 {
    padding-right: 35px;
}

.pr-40 {
    padding-right: 40px;
}

.pr-45 {
    padding-right: 45px;
}

.pr-50 {
    padding-right: 50px;
}

.pr-55 {
    padding-right: 55px;
}

.pr-60 {
    padding-right: 60px;
}

.pr-65 {
    padding-right: 65px;
}

.pr-70 {
    padding-right: 70px;
}

.pr-75 {
    padding-right: 75px;
}

.pr-80 {
    padding-right: 80px;
}

.pr-85 {
    padding-right: 85px;
}

.pr-90 {
    padding-right: 90px;
}

.pr-95 {
    padding-right: 95px;
}

.pr-100 {
    padding-right: 100px;
}

.pr-105 {
    padding-right: 105px;
}

.pr-110 {
    padding-right: 110px;
}

.pr-115 {
    padding-right: 100px;
}

.pr-120 {
    padding-right: 115px;
}

.pr-125 {
    padding-right: 125px;
}

.pr-130 {
    padding-right: 130px;
}

.pr-135 {
    padding-right: 135px;
}

.pr-140 {
    padding-right: 140px;
}

.pr-145 {
    padding-right: 145px;
}

.pr-150 {
    padding-right: 150px;
}
.dashboard-w1 {
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    min-height: 130px;
    justify-content: flex-end;
    overflow: hidden;
    transition: all 0.3s;
    -webkit-transition: all 0.3s;
    -moz-transition: all 0.3s;
    -ms-transition: all 0.3s;
    -o-transition: all 0.3s;
    position: relative;
    align-items: center;
    padding: 30px 20px;
}

.dashboard-w1:hover {
    transform: translateY(-3px);
    -webkit-transform: translateY(-3px);
    -moz-transform: translateY(-3px);
    -ms-transform: translateY(-3px);
    -o-transform: translateY(-3px);
}

.dashboard-w1 .icon {
    position: absolute;
    bottom: 0;
    left: 0;
}

.dashboard-w1 .icon i {
    font-size: 72px;
    color: rgba(255, 255, 255, 0.15);
    margin-left: -15px;
    margin-bottom: -4px;
}

.dashboard-w1 .details {
    text-align: right;
}

.dashboard-w1 .details .status,
.dashboard-w1 .details .amount,
.dashboard-w1 .details .currency-sign {
    color: #ffffff;
    font-size: 24px;
    font-weight: 500;
    line-height: 1;
}

.dashboard-w1 .details .desciption span {
    color: #ffffff;
    font-size: 14px;
    font-weight: 300;
    display: inline-block;
    margin-top: 5px;
}
.bg--gradi-1, .overlay--gradi-1[class*="overlay"]::before {
    background: #4776E6 !important;
    background: -webkit-linear-gradient(to top, #8E54E9, #4776E6) !important;
    background: linear-gradient(to top, #8E54E9, #4776E6) !important;
}
.bg--gradi-10, .overlay--gradi-10[class*="overlay"]::before {
    background: #4568DC !important;
    background: -webkit-linear-gradient(to bottom, #B06AB3, #4568DC) !important;
    background: linear-gradient(to bottom, #B06AB3, #4568DC) !important;
}

.bg--gradi-11, .overlay--gradi-11[class*="overlay"]::before {
    background: #ee0979 !important;
    background: -webkit-linear-gradient(to bottom, #ff6a00, #ee0979) !important;
    background: linear-gradient(to bottom, #ff6a00, #ee0979) !important;
}

.bg--gradi-12, .overlay--gradi-12[class*="overlay"]::before {
    background: #41295a !important;
    background: -webkit-linear-gradient(to bottom, #2F0743, #41295a) !important;
    background: linear-gradient(to bottom, #2F0743, #41295a) !important;
}

.bg--gradi-13, .overlay--gradi-13[class*="overlay"]::before {
    background: #4ECDC4 !important;
    background: -webkit-linear-gradient(to bottom, #556270, #4ECDC4) !important;
    background: linear-gradient(to bottom, #556270, #4ECDC4) !important;
}

.bg--gradi-14, .overlay--gradi-14[class*="overlay"]::before {
    background: #f85032 !important;
    background: -webkit-linear-gradient(to bottom, #e73827, #f85032) !important;
    background: linear-gradient(to bottom, #e73827, #f85032) !important;
}

.bg--gradi-15, .overlay--gradi-15[class*="overlay"]::before {
    background: #cb2d3e !important;
    background: -webkit-linear-gradient(to bottom, #ef473a, #cb2d3e) !important;
    background: linear-gradient(to bottom, #ef473a, #cb2d3e) !important;
}

.bg--gradi-16, .overlay--gradi-16[class*="overlay"]::before {
    background: #56ab2f !important;
    background: -webkit-linear-gradient(to bottom, #a8e063, #56ab2f) !important;
    background: linear-gradient(to bottom, #a8e063, #56ab2f) !important;
}

.bg--gradi-17, .overlay--gradi-17[class*="overlay"]::before {
    background: #000428 !important;
    background: -webkit-linear-gradient(to bottom, #004e92, #000428) !important;
    background: linear-gradient(to bottom, #004e92, #000428) !important;
}

.bg--gradi-18, .overlay--gradi-18[class*="overlay"]::before {
    background: #42275a !important;
    background: -webkit-linear-gradient(to bottom, #734b6d, #42275a) !important;
    background: linear-gradient(to bottom, #734b6d, #42275a) !important;
}

.bg--gradi-19, .overlay--gradi-19[class*="overlay"]::before {
    background: #141E30 !important;
    background: -webkit-linear-gradient(to bottom, #243B55, #141E30) !important;
    background: linear-gradient(to bottom, #243B55, #141E30) !important;
}

.bg--gradi-20, .overlay--gradi-20[class*="overlay"]::before {
    background: #2C3E50 !important;
    background: -webkit-linear-gradient(to bottom, #4CA1AF, #2C3E50) !important;
    background: linear-gradient(to bottom, #4CA1AF, #2C3E50) !important;
}

.bg--gradi-21, .overlay--gradi-21[class*="overlay"]::before {
    background: #3a7bd5 !important;
    background: -webkit-linear-gradient(to bottom, #3a6073, #3a7bd5) !important;
    background: linear-gradient(to bottom, #3a6073, #3a7bd5) !important;
}

.bg--gradi-21, .overlay--gradi-21[class*="overlay"]::before {
    background: #ff4b1f !important;
    background: -webkit-linear-gradient(to bottom, #ff9068, #ff4b1f) !important;
    background: linear-gradient(to bottom, #ff9068, #ff4b1f) !important;
}

.bg--gradi-22, .overlay--gradi-22[class*="overlay"]::before {
    background: #4B79A1 !important;
    background: -webkit-linear-gradient(to bottom, #283E51, #4B79A1) !important;
    background: linear-gradient(to bottom, #283E51, #4B79A1) !important;
}

.bg--gradi-23, .overlay--gradi-23[class*="overlay"]::before {
    background: #2980b9 !important;
    background: -webkit-linear-gradient(to bottom, #2c3e50, #2980b9) !important;
    background: linear-gradient(to bottom, #2c3e50, #2980b9) !important;
}

.bg--gradi-24, .overlay--gradi-24[class*="overlay"]::before {
    background: #1e3c72 !important;
    background: -webkit-linear-gradient(to bottom, #2a5298, #1e3c72) !important;
    background: linear-gradient(to bottom, #2a5298, #1e3c72) !important;
}

.bg--gradi-25, .overlay--gradi-25[class*="overlay"]::before {
    background: #fd746c !important;
    background: -webkit-linear-gradient(to bottom, #ff9068, #fd746c) !important;
    background: linear-gradient(to bottom, #ff9068, #fd746c) !important;
}

.bg--gradi-26, .overlay--gradi-26[class*="overlay"]::before {
    background: #6a3093 !important;
    background: -webkit-linear-gradient(to bottom, #a044ff, #6a3093) !important;
    background: linear-gradient(to bottom, #a044ff, #6a3093) !important;
}

.bg--gradi-27, .overlay--gradi-27[class*="overlay"]::before {
    background: #457fca !important;
    background: -webkit-linear-gradient(to bottom, #5691c8, #457fca) !important;
    background: linear-gradient(to bottom, #5691c8, #457fca) !important;
}

.bg--gradi-28, .overlay--gradi-28[class*="overlay"]::before {
    background: #B24592 !important;
    background: -webkit-linear-gradient(to bottom, #F15F79, #B24592) !important;
    background: linear-gradient(to bottom, #F15F79, #B24592) !important;
}

.bg--gradi-29, .overlay--gradi-29[class*="overlay"]::before {
    background: #FFB75E !important;
    background: -webkit-linear-gradient(to bottom, #ED8F03, #FFB75E) !important;
    background: linear-gradient(to bottom, #ED8F03, #FFB75E) !important;
}

.bg--gradi-30, .overlay--gradi-30[class*="overlay"]::before {
    background: #8E0E00 !important;
    background: -webkit-linear-gradient(to bottom, #1F1C18, #8E0E00) !important;
    background: linear-gradient(to bottom, #1F1C18, #8E0E00) !important;
}

.bg--gradi-31, .overlay--gradi-31[class*="overlay"]::before {
    background: #76b852 !important;
    background: -webkit-linear-gradient(to bottom, #8DC26F, #76b852) !important;
    background: linear-gradient(to bottom, #8DC26F, #76b852) !important;
}

.bg--gradi-32, .overlay--gradi-32[class*="overlay"]::before {
    background: #673AB7 !important;
    background: -webkit-linear-gradient(to bottom, #512DA8, #673AB7) !important;
    background: linear-gradient(to bottom, #512DA8, #673AB7) !important;
}

.bg--gradi-33, .overlay--gradi-33[class*="overlay"]::before {
    background: #f46b45 !important;
    background: -webkit-linear-gradient(to bottom, #eea849, #f46b45) !important;
    background: linear-gradient(to bottom, #eea849, #f46b45) !important;
}

.bg--gradi-34, .overlay--gradi-34[class*="overlay"]::before {
    background: #005C97 !important;
    background: -webkit-linear-gradient(to bottom, #363795, #005C97) !important;
    background: linear-gradient(to bottom, #363795, #005C97) !important;
}

.bg--gradi-35, .overlay--gradi-35[class*="overlay"]::before {
    background: #e53935 !important;
    background: -webkit-linear-gradient(to bottom, #e35d5b, #e53935) !important;
    background: linear-gradient(to bottom, #e35d5b, #e53935) !important;
}

.bg--gradi-36, .overlay--gradi-36[class*="overlay"]::before {
    background: #2c3e50 !important;
    background: -webkit-linear-gradient(to bottom, #3498db, #2c3e50) !important;
    background: linear-gradient(to bottom, #3498db, #2c3e50) !important;
}

.bg--gradi-37, .overlay--gradi-37[class*="overlay"]::before {
    background: #6A9113 !important;
    background: -webkit-linear-gradient(to bottom, #141517, #6A9113) !important;
    background: linear-gradient(to bottom, #141517, #6A9113) !important;
}

.bg--gradi-38, .overlay--gradi-38[class*="overlay"]::before {
    background: #136a8a !important;
    background: -webkit-linear-gradient(to bottom, #267871, #136a8a) !important;
    background: linear-gradient(to bottom, #267871, #136a8a) !important;
}

.bg--gradi-39, .overlay--gradi-39[class*="overlay"]::before {
    background: #6441A5 !important;
    background: -webkit-linear-gradient(to bottom, #2a0845, #6441A5) !important;
    background: linear-gradient(to bottom, #2a0845, #6441A5) !important;
}

.bg--gradi-40, .overlay--gradi-40[class*="overlay"]::before {
    background: #43cea2 !important;
    background: -webkit-linear-gradient(to bottom, #185a9d, #43cea2) !important;
    background: linear-gradient(to bottom, #185a9d, #43cea2) !important;
}

.bg--gradi-41, .overlay--gradi-41[class*="overlay"]::before {
    background: #00c6ff !important;
    background: -webkit-linear-gradient(to bottom, #0072ff, #00c6ff) !important;
    background: linear-gradient(to bottom, #0072ff, #00c6ff) !important;
}

.bg--gradi-42, .overlay--gradi-42[class*="overlay"]::before {
    background: #9D50BB !important;
    background: -webkit-linear-gradient(to bottom, #6E48AA, #9D50BB) !important;
    background: linear-gradient(to bottom, #6E48AA, #9D50BB) !important;
}

.bg--gradi-43, .overlay--gradi-43[class*="overlay"]::before {
    background: #ADD100 !important;
    background: -webkit-linear-gradient(to bottom, #7B920A, #ADD100) !important;
    background: linear-gradient(to bottom, #7B920A, #ADD100) !important;
}

.bg--gradi-44, .overlay--gradi-44[class*="overlay"]::before {
    background: #00d2ff !important;
    background: -webkit-linear-gradient(to bottom, #3a7bd5, #00d2ff) !important;
    background: linear-gradient(to bottom, #3a7bd5, #00d2ff) !important;
}

.bg--gradi-45, .overlay--gradi-45[class*="overlay"]::before {
    background: #a73737 !important;
    background: -webkit-linear-gradient(to bottom, #7a2828, #a73737) !important;
    background: linear-gradient(to bottom, #7a2828, #a73737) !important;
}

.bg--gradi-46, .overlay--gradi-46[class*="overlay"]::before {
    background: #4b6cb7 !important;
    background: -webkit-linear-gradient(to bottom, #182848, #4b6cb7) !important;
    background: linear-gradient(to bottom, #182848, #4b6cb7) !important;
}

.bg--gradi-47, .overlay--gradi-47[class*="overlay"]::before {
    background: #e43a15 !important;
    background: -webkit-linear-gradient(to bottom, #e65245, #e43a15) !important;
    background: linear-gradient(to bottom, #e65245, #e43a15) !important;
}

.bg--gradi-48, .overlay--gradi-48[class*="overlay"]::before {
    background: #C04848 !important;
    background: -webkit-linear-gradient(to bottom, #480048, #C04848) !important;
    background: linear-gradient(to bottom, #480048, #C04848) !important;
}

.bg--gradi-49, .overlay--gradi-49[class*="overlay"]::before {
    background: #232526 !important;
    background: -webkit-linear-gradient(to bottom, #414345, #232526) !important;
    background: linear-gradient(to bottom, #414345, #232526) !important;
}

.bg--gradi-50, .overlay--gradi-50[class*="overlay"]::before {
    background: #4776E6 !important;
    background: -webkit-linear-gradient(to bottom, #8E54E9, #4776E6) !important;
    background: linear-gradient(to bottom, #8E54E9, #4776E6) !important;
}
.box--shadow1 {
    box-shadow: 0px 5px 26px -5px #cdd4e7 !important;
}

.box--shadow2 {
    box-shadow: 0 0.5rem 1rem rgba(18, 38, 63, 0.1) !important;
}

.box--shadow3 {
    box-shadow: 0 3px 5px 0 rgba(18, 38, 63, 0.2) !important;
}

.b-radius--3 {
    border-radius: 3px !important;
    -webkit-border-radius: 3px !important;
    -moz-border-radius: 3px !important;
    -ms-border-radius: 3px !important;
    -o-border-radius: 3px !important;
}

.b-radius--4 {
    border-radius: 4px !important;
    -webkit-border-radius: 4px !important;
    -moz-border-radius: 4px !important;
    -ms-border-radius: 4px !important;
    -o-border-radius: 4px !important;
}

.b-radius--5 {
    border-radius: 5px !important;
    -webkit-border-radius: 5px !important;
    -moz-border-radius: 5px !important;
    -ms-border-radius: 5px !important;
    -o-border-radius: 5px !important;
}

.b-radius--6 {
    border-radius: 6px !important;
    -webkit-border-radius: 6px !important;
    -moz-border-radius: 6px !important;
    -ms-border-radius: 6px !important;
    -o-border-radius: 6px !important;
}

.b-radius--7 {
    border-radius: 7px !important;
    -webkit-border-radius: 7px !important;
    -moz-border-radius: 7px !important;
    -ms-border-radius: 7px !important;
    -o-border-radius: 7px !important;
}

.b-radius--8 {
    border-radius: 8px !important;
    -webkit-border-radius: 8px !important;
    -moz-border-radius: 8px !important;
    -ms-border-radius: 8px !important;
    -o-border-radius: 8px !important;
}

.b-radius--9 {
    border-radius: 9px !important;
    -webkit-border-radius: 9px !important;
    -moz-border-radius: 9px !important;
    -ms-border-radius: 9px !important;
    -o-border-radius: 9px !important;
}

.b-radius--10 {
    border-radius: 10px !important;
    -webkit-border-radius: 10px !important;
    -moz-border-radius: 10px !important;
    -ms-border-radius: 10px !important;
    -o-border-radius: 10px !important;
}
.has--link {
    position: relative;
}

.has--link .item--link {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}
.toggle-group .toggle-handle {
    background-color: #10163A;
}

.toggle-group .toggle-off {
    background-color: #293654;
    color: #ffffff;
}

.toggle input[data-size="small"] ~ .toggle-group label {
    font-size: 0.75rem;
}
.btn--primary {
    background-color: #7367f0 !important;
}

.btn--primary:hover {
    background-color: #5e50ee !important;
}

.btn--secondary {
    background-color: #868e96 !important;
}

.btn--secondary:hover {
    background-color: #78818a !important;
}

.btn--success {
    background-color: #28c76f !important;
}

.btn--success:hover {
    background-color: #24b263 !important;
}

.btn--danger {
    background-color: #ea5455 !important;
}

.btn--danger:hover {
    background-color: #e73d3e !important;
}

.btn--warning {
    background-color: #ff9f43 !important;
}

.btn--warning:hover {
    background-color: #ff922a !important;
}

.btn--info {
    background-color: #1e9ff2 !important;
}

.btn--info:hover {
    background-color: #0d93e9 !important;
}

.btn--dark {
    background-color: #10163A !important;
}

.btn--dark:hover {
    background-color: #0a0e26 !important;
}

.btn--primary, .btn--secondary, .btn--success, .btn--danger, .btn--warning, .btn--info, .btn--dark {
    color: #ffffff;
}

.btn--primary:hover, .btn--secondary:hover, .btn--success:hover, .btn--danger:hover, .btn--warning:hover, .btn--info:hover, .btn--dark:hover {
    color: #ffffff;
}

.btn-outline--primary:hover, .btn-outline--secondary:hover, .btn-outline--success:hover, .btn-outline--danger:hover, .btn-outline--warning:hover, .btn-outline--info:hover, .btn-outline--dark:hover {
    color: #ffffff;
}
.icon-btn {
    padding: 3px 8px;
    background-color: #7367f0;
    color: #ffffff;
    border-radius: 3px;
    font-size: 13px;
}
a.icon-btn {
    padding: 4.5px 7px;
}

.icon-btn:hover {
    color: #ffffff;
}
.icon-btn-danger {
    padding: 3px 8px;
    background-color: #ff0000;
    color: #ffffff;
    border-radius: 3px;
    font-size: 13px;
}
a.icon-btn-danger {
    padding: 4.5px 7px;
}

.icon-btn-danger:hover {
    color: #ffffff;
}<?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/extra/css.blade.php ENDPATH**/ ?>