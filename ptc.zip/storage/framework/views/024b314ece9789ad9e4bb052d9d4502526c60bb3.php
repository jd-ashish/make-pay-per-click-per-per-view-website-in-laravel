

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Membership",array("Home","Membership","index"),"")); ?>

<!-- end row -->

<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">

        <div class="card mb-3">

            <div class="card-header">
                <h3><i class="fas fa-table"></i> Invoice Upgrade to <?php echo e($member->name); ?></h3>
            </div>

            <div class="card-body">

                <div class="container">

                    <div class="row">

                        <div class="col-md-12">

                            <div class="invoice-title text-center mb-3">
                                <h2>ORDER ID : #<?php echo e($order['id']); ?></h2>
                                <strong>Date:</strong> <?php echo e(date(setting_val('date_formate'))); ?>

                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-xs-12 col-sm-12 col-md-6">
                                    <h5>Billed To:</h5>
                                    <address>
                                        <?php echo e(setting_val("APP_NAME")); ?><br>
                                        <?php echo e(setting_val("address")); ?><br>
                                        <?php echo e(setting_val("city")); ?> , <?php echo e(setting_val("state")); ?> <br>
                                        
                                        <?php echo e(setting_val("country")); ?> , <?php echo e(setting_val("zip")); ?>

                                    </address>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-6 text-right">
                                    <h5>Shipped To:</h5><br>
                                    <address>
                                        <?php echo e(Auth::user()->name); ?><br>
                                        <?php if(Auth::user()->details): ?>
                                            <?php echo e(Auth::user()->details->address); ?><br>
                                            <?php echo e(Auth::user()->details->city); ?> , <?php echo e(Auth::user()->details->state); ?><br>
                                            <?php echo e(Auth::user()->details->country); ?>, <?php echo e(Auth::user()->details->zip); ?>

                                        <?php else: ?>
                                            <a>You need compelete profile details</a>
                                        <?php endif; ?>
                                    </address>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-xs-12 col-md-6">
                                    
                                </div>
                                <div class="col-xs-12 col-md-6 text-right">
                                    <h5>Order Date:</h5>
                                    <address>
                                        <?php echo e(date(setting_val('date_formate'))); ?><br><br>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title"><strong>Order summary</strong></h3>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <thead>
                                                <tr>
                                                    <td><strong>Item</strong></td>
                                                    <td class="text-center"><strong>Price</strong>
                                                    </td>
                                                    <td class="text-center">
                                                        <strong>Quantity</strong></td>
                                                    <td class="text-right"><strong>Totals</strong>
                                                    </td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><?php echo e($member->name); ?></td>
                                                    <td class="text-center"> <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($member->price); ?></td>
                                                    <td class="text-center">1</td>
                                                    <td class="text-right"><?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($member->price*1); ?></td>
                                                </tr>
                                                <tr>
                                                    <td class="no-line"></td>
                                                    <td class="no-line"></td>
                                                    <td class="no-line text-center">
                                                        <strong>Total</strong></td>
                                                    <td class="no-line text-right"><?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($member->price*1); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="panal-footer float-right">
                                    <?php if(!Auth::user()->details): ?>
                                    <form action="<?php echo e(route('payment')); ?>" method="POST" >
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="member_id" value="<?php echo e($member->id); ?>">
                                        <script src="https://checkout.razorpay.com/v1/checkout.js"
                                                data-key="<?php echo e(env('RZP_api_key')); ?>"
                                                data-amount="<?php echo e($arr['amt']*100); ?>"
                                                data-currency="<?php echo e(env('CURRENCY_SYMB')); ?>"
                                                data-buttontext="Pay <?php echo e($arr['amt']); ?> <?php echo e(env('CURRENCY_SYMB')); ?>"
                                                data-name="<?php echo e(Auth::user()->name); ?>"
                                                data-description="<?php echo e($member->name); ?>"
                                                data-image="<?php echo e(asset('/image/nice.png')); ?>"
                                                data-order_id= "<?php echo e($order['id']); ?>",
                                                data-prefill.name="<?php echo e(Auth::user()->name); ?>"
                                                data-prefill.email="<?php echo e(Auth::user()->email); ?>"
                                                data-theme.color="#9FE2BF">
                                        </script>
                                    </form>
                                        <?php else: ?>
                                            <a>You need compelete profile details</a>
                                        <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- end card body -->

        </div>
        <!-- end card-->

    </div>
    <!-- end col-->

</div>
<!-- end row-->



<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- BEGIN Java Script for this page -->
<script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
<!-- END Java Script for this page -->
<script src="<?php echo e(asset('js/users/users.js')); ?>"></script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/payment/razorpay.blade.php ENDPATH**/ ?>