<form method="post" action="<?php echo e(route('testiminial.save')); ?>">
    <?php echo csrf_field(); ?>
    <textarea rows="8" class="form-control" name="description"></textarea>

    <button class="btn btn-dribbble float-right mt-2" >Supports us</button>
</form><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/faq/rate.blade.php ENDPATH**/ ?>