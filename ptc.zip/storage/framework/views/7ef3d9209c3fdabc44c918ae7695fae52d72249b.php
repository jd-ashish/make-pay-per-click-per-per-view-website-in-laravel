
<?php $__env->startSection('title'); ?>
    Withdrawl section | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>" />
    <link href="<?php echo e(asset('assets/css/pricing-tables.css" rel="stylesheet')); ?>" type="text/css" />
    <style>
        .same-height{
            height: 42px !important;
        }
        .tabco1{
            font-weight: bold;
        }

        .select2-selection__rendered {
    line-height: 42px !important;
    border-radius: 0px !important;
    background: #E9ECEF !important;
}
.select2-container .select2-selection--single {
    height: 42px !important;
    border-radius: 0px !important;
    background: #E9ECEF !important;
}
.select2-selection__arrow {
    height: 42px !important;
    border-radius: 0px !important;
    background: #E9ECEF !important;
}
        </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Withdraw section",array("home","dashbort","withdraw","index"),"")); ?>

<!-- end row -->

<div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong><?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e(setting_val('withdraw_limit')); ?> !</strong> Minimum withdrawl.
</div>

<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <form method="POST" action="<?php echo e(route('withdrawl.request')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-append same-height">
                            <span class="input-group-text"><h3><i class="fas fa-wallet"></i> <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e(Auth::user()->balance); ?></h3></span>
                        </div>
                        <input type="number" name="balance" class="form-control same-height" placeholder="Enter amount" min="<?php echo e(setting_val('withdraw_limit')); ?>" max="<?php echo e(Auth::user()->balance); ?>" required>
                        <div class="input-group-append same-height">
                          <select class="select2-selection__rendered js-example-basic-multiple js-states form-control select2 pm" name="pm" id="id_label_multiple" style="width: 100%" required>
                            <option value="">Select payment method</option>    
                                <?php $__currentLoopData = json_decode(setting_val("Withdraw_options"),true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </div>
                        <div class="input-group-append same-height">
                          <button type="submit" class="input-group-text">Withdrawl now</button>
                        </div>
                    </div>
                    <input type="text" placeholder="Payment details" name="pd" class="form-control pd" style="resize: both; display: none;" required>
                </form>
            </div>
<?php
    setting_val("")
?>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Amount</th>
                                <th>payment method</th>
                                <th>Payment description</th>
                                <th>Status</th>
                                <th>Time</th>
                                
                            </tr>
                        </thead>
                        <body>
                            <?php $__currentLoopData = $Withdraw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($key+1)); ?></td>
                                    <td> <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($value->amount); ?></td>
                                    <td><strong><?php echo e($value->payment_method); ?></strong></td>
                                    <td><?php echo e($value->payment_details); ?></td>
                                    <td><?= status($value->status)?></td>
                                    <td><?php echo e(Time_ago(strtotime($value->created_at))); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </body>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- BEGIN Java Script for this page -->
<script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
<script>
    $(".pm").change(function(){
        var val = $(this).val();
        if(val!=""){
            $(".pd").show();
            $(".pd").attr('placeholder', 'Enter Payment details of '+val );
        }else{
            $(".pd").show();
            $(".pd").attr('placeholder', "Please select payment options" );
        }
        
    })
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/index/withdraw.blade.php ENDPATH**/ ?>