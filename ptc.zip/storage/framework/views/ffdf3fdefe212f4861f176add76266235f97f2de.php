
<?php $__env->startSection('title'); ?>
    Referral User overview | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Referral User",array("home","Referral","users","Earn by level"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Referral Link</label>
                            <div class="input-group">
                                <input type="text" value="<?php echo e(url('/')); ?>/ref/<?php echo e(Auth::user()->email); ?>"
                                class="form-control form-control-lg" id="referralURL"
                                readonly>
                                <div class="input-group-append copytextDiv" style="cursor: pointer">
                                    <span class="input-group-text copytext" id="copyBoard"> <i class="fa fa-copy"></i> </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-body">
                <div class="container-fluid row">
                    <div class="col-sm-12">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>You</th>
                                        <th>level</th>
                                        <th>Earn from</th>
                                        <th>Amount</th>
                                        <th>Time</th>
                                    </tr>
                                </thead>
                                <body>
                                    <?php $__currentLoopData = $ReferralUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e(($key+1)); ?></th>
                                            <td class="text-success"> <?php echo e(\App\Models\User::where('id',$value->refer_id)->first()->name); ?></td>
                                            <td class="text-bold" style="color: green"><?php echo e($value->level); ?> Level</td>
                                            <td><?php echo e(\App\Models\User::where('id',$value->auth_id)->first()->name); ?></td>
                                            <th><?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($value->amount); ?></th>
                                            <td><?php echo e(Time_ago(strtotime($value->created_at))); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </body>
                            </table>
                        </div>
                    </div>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    (function ($) {
        "use strict";
        $('#copyBoard').click(function(){
            var copyText = document.getElementById("referralURL");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            /*For mobile devices*/
            document.execCommand("copy");
            iziToast.success({message: "Copied: " + copyText.value, position: "topRight"});
        });
    })(jQuery);
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/Referral/ReferralUser.blade.php ENDPATH**/ ?>