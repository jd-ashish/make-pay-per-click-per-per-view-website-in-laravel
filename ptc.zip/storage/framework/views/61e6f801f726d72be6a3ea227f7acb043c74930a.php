<?php echo e($slot); ?>

<?php /**PATH G:\Database\htdocs\pro\ptc\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>