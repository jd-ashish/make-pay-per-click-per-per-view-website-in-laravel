
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>" />
    <link href="<?php echo e(asset('assets/css/pricing-tables.css" rel="stylesheet')); ?>" type="text/css" />
    <style>
        .same-height{
            height: 42px !important;
        }
        .tabco1{
            font-weight: bold;
        }
        </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Wallet",array("home","user","wallet"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <form method="POST" action="<?php echo e(route('wallet.add.money')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-group mb-3">
                        <div class="input-group-append same-height">
                            <span class="input-group-text"><h3><i class="fas fa-wallet"></i> <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e(Auth::user()->balance); ?></h3></span>
                        </div>
                        <input type="number" name="balance" class="form-control same-height" placeholder="Enter amount" min="1">
                        <div class="input-group-append same-height">
                          <button type="submit" class="input-group-text">Add money</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Amount</th>
                                <th>Type</th>
                                <th>Payment Type</th>
                                <th>Check</th>
                                <th>Time</th>
                                
                            </tr>
                        </thead>
                        <body>
                            <?php $__currentLoopData = $wallet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($key+1)); ?></td>
                                    <td> <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($value->amount); ?></td>
                                    <td><strong><?php echo e($value->type); ?></strong></td>
                                    <td><?php echo e($value->payment_type); ?></td>
                                    <td><?php if($value->payment_details!=""): ?>
                                            <a href="javascript::void();" data-fancybox="modal" data-src="#get_wallet_statement_details" role="button" >Check</a>
                                            <div id="get_wallet_statement_details" style="display: none; padding: 40px ; max-width: 85%;">
                                                <div class="card-body">

                                                    <div class="table-responsive">
                                                    <table class="table table-condensed table-hover table-bordered table-responsive-sm">
                                                        <thead>
                                                            <tr>
                                                                <th class="tabco1" style="min-width:200px">Tag</th>
                                                                <th class="tabco2" style="min-width:200px">Details</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td class="tabco1">ID</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->id); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Order ID</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->order_id); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Amount</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e(json_decode($value->payment_details)->amount/100); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Method</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->method); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Status</td>
                                                                <td class="tabco2">
                                                                    <?php if(json_decode($value->payment_details)->captured==true): ?>
                                                                        <i class="fas fa-check rightSign" aria-hidden="true"></i>
                                                                    <?php else: ?>
                                                                        <i class="fas fa-check crossSign" aria-hidden="true"></i>
                                                                    <?php endif; ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Description</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->description); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Email</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->email); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Phone</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->contact); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Bank</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->bank); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">card ID</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->card_id); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Wallet</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->wallet); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">UPI</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(json_decode($value->payment_details)->vpa); ?>

                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Transaction</td>
                                                                <td class="tabco2">
                                                                    <?= status(json_decode($value->payment_details)->status)?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td class="tabco1">Created at</td>
                                                                <td class="tabco2">
                                                                    <?php echo e(Time_ago((json_decode($value->payment_details)->created_at))); ?>

                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Time_ago(strtotime($value->created_at))); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </body>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- BEGIN Java Script for this page -->
<script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/index/wallet.blade.php ENDPATH**/ ?>