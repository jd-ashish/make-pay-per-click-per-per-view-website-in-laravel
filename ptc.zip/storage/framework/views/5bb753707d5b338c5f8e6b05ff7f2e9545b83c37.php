
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>" />
    <link href="<?php echo e(asset('assets/css/pricing-tables.css" rel="stylesheet')); ?>" type="text/css" />
    <style>
        .same-height{
            height: 42px !important;
        }
        .tabco1{
            font-weight: bold;
        }
        </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Faq",array("home","user","faq"),"")); ?>

<!-- end row -->

<?php echo e(back_link(route('home'))); ?>

<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3 data-fancybox="modal" data-src="#faq" role="button"><i class="fas fa-table"></i> Ask</h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>User id</th>
                                <th>Questions</th>
                                <th>Answeres</th>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <body>
                           <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                   <td><?php echo e(($key+1)); ?></td>
                                   <td><?php echo e($item->user_id); ?></td>
                                   <td><?php echo e($item->q); ?></td>
                                   <td><?php echo e($item->a); ?></td>
                                   <td><?php echo e(Time_ago(strtotime($item->created_at))); ?></td>
                                   <td><a href="<?php echo e(route('faq.delete',$item->id)); ?>" class="btn btn-facebook btn-sm">Delete</a></td>
                               </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </body>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->

<div id="faq" style="display: none; padding: 40px ; max-width: 85%;">
    
    <form action="<?php echo e(route('faq.store')); ?>" style="width: 1222px" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="q">Enter questions:</label>
          <textarea class="form-control" placeholder="Enter questions" rows="5" id="q" name="q" required></textarea>
        </div>
        <div class="form-group">
          <label for="a">Answere:</label>
          <textarea class="form-control" placeholder="Enter questions related answere" role="5" id="a" name="a"></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- BEGIN Java Script for this page -->
<script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>