

<?php $__env->startSection('title'); ?>
    SMS Configurations | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade('<i class="fas fa-sms"></i> SMS Configurations',array("home","SMS Manager","Config","index"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-sms"></i> SMS Configurations</h3>
            </div>
            <div class="panel-body">
                <form class="form-horizontal" action="<?php echo e(route('sms.config.save')); ?>"  method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="hidden" name="types[]" value="MAIL_DRIVER">
                        <div class="col-lg-3">
                            <label class="control-label"><?php echo e(__('Sms DRIVER')); ?></label>
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" name="sms_pkg" onchange="checkSmsPkg()">
                                <option value="">Select sms driver</option>
                                <option value="fast2sms" <?php if(setting_val('sms_pkg') == "fast2sms"): ?> selected <?php endif; ?>>Fast2Sms</option>
                                <option value="twilio" <?php if(setting_val('sms_pkg') == "twilio"): ?> selected <?php endif; ?>>Twilio</option>
                            </select>
                        </div>
                    </div>
                    <div class="fast2sms" style="display: none;">
                        <div class="form-group">
                            <div class="col-lg-3">
                                <label class="control-label"><?php echo e(__('DLT TYPE')); ?></label>
                            </div>
                            <div class="col-lg-6">
                                <select class="form-control" name="DLT_SLT" onchange="dltSelect()">
                                    
                                    <option value="">Select DLT type</option>
                                    <option value="dlt" <?php if(setting_val('fast2sms_with_dlt') == "on"): ?> selected <?php endif; ?>>DLT</option>
                                    <option value="without_dlt" <?php if(setting_val('fast2sms_without_dlt') == "on"): ?> selected <?php endif; ?>>Without DLT</option>
                                    
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-lg-3">
                                <label class="control-label"><?php echo e(__('FAST2SMS_KEY')); ?></label>
                            </div>
                            <div class="col-lg-6">
                                <input type="text" class="form-control" name="FAST2SMS_KEY" value="<?php echo e(env('FAST2SMS_KEY')); ?>" placeholder="FAST2SMS KEY">
                            </div>
                        </div>
                        <div class="dlt_sec" style="display: none;">
                            <div class="form-group">
                                <div class="col-lg-3">
                                    <label class="control-label"><?php echo e(__('ROUTE')); ?></label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" name="route" value="dlt" readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-3">
                                    <label class="control-label"><?php echo e(__('sender id')); ?></label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" name="sender_id" value="<?php echo e(json_decode(setting_val("fast2sms_dlt_details"))->sender_id); ?>" placeholder="Enter sender ID">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-3">
                                    <label class="control-label"><?php echo e(__('Message id')); ?></label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" name="message" value="<?php echo e(json_decode(setting_val("fast2sms_dlt_details"))->message); ?>" placeholder="Enter message ID">
                                    <small class="text-danger">Message id must contain only Like : Dear user your OTP from <?php echo e(env('APP_NAME')); ?> : {#var#}</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="twilio" style="display: none;">
                        


                        <div class="form-group">
                            <div class="col-lg-3">
                                <label class="control-label"><?php echo e(__('TWILIO SID')); ?></label>
                            </div>
                            <div class="col-lg-6">
                                <input type="text" class="form-control" name="TWILIO_SID" value="<?php echo e(env('TWILIO_SID')); ?>" placeholder="TWILIO SID">
                            </div>
                        </div>
                        <div>
                            <div class="form-group">
                                <div class="col-lg-3">
                                    <label class="control-label"><?php echo e(__('TWILIO TOKEN')); ?></label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" name="TWILIO_TOKEN" value="<?php echo e(env('TWILIO_TOKEN')); ?>" placeholder="TWILIO TOKEN">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-3">
                                    <label class="control-label"><?php echo e(__('TWILIO FROM')); ?></label>
                                </div>
                                <div class="col-lg-6">
                                    <input type="text" class="form-control" name="TWILIO_FROM" value="<?php echo e(env('TWILIO_FROM')); ?>" placeholder="TWILIO FROM">
                                    <small class="text-danger">TWILIO FROM means that it will-be SENDER ID or number like +120*****986</small>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    
                    
                    <div class="form-group">
                        <div class="col-lg-12 text-right">
                            <button class="btn btn-googleplus" type="submit"><?php echo e(__('Save')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
            

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">
    $(document).ready(function(){
        checkSmsPkg();
        dltSelect();
    });
    function checkSmsPkg(){
        if($('select[name=sms_pkg]').val() == 'fast2sms'){
            $('.fast2sms').show();
            $('.twilio').hide();
        }
        if($('select[name=sms_pkg]').val() == 'twilio'){
            $('.fast2sms').hide();
            $('.twilio').show();
        }
    }
    function dltSelect(){
        if($('select[name=DLT_SLT]').val() == 'dlt'){
            $('.dlt_sec').show();
        }
        else{
            $('.dlt_sec').hide();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/sms_manager/config.blade.php ENDPATH**/ ?>