
<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e($user->name." Details"); ?> | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Users",array("home","Users","View","Users details"),"")); ?>

<!-- end row -->
<div class="row mb-none-30">
    <div class="col-xl-3 col-lg-5 col-md-5 mb-30">

        <div class="card b-radius--10 overflow-hidden box--shadow1">
            <div class="card-body p-0">
                <div class="p-3 bg--white">
                    <div class="">
                        <img src="<?php if($user->details): ?><?php echo e(url('/').'/'.$user->details->avtar_image); ?><?php endif; ?>" alt="profile-image" class="b-radius--10 w-100">
                    </div>
                    <div class="mt-15">
                        <h4 class=""><?php echo e($user->name); ?></h4>
                        <span class="text--small">Joined At <strong><?php echo e($user->created_at); ?></strong></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="card b-radius--10 overflow-hidden mt-30 box--shadow1">
            <div class="card-body">
                <h5 class="mb-20 text-muted">User information</h5>
                <ul class="list-group">

                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Username                            <span class="font-weight-bold text-decoration-none">[Email-Id]</span>
                    </li>


                    <li class="list-group-item d-flex justify-content-between align-items-center">Status
                    <?php if($user->email_verified_at==""): ?>
                        <?= status("pending")?>
                    <?php else: ?>
                        <?= status("Active")?>
                    <?php endif; ?>
                    </li>
                    <?php
                        $ru = 0;
                        $rc = 0;
                    ?>
                    <?php $__currentLoopData = $ReferralUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $ru++;
                            $rc += $value->amount;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Balance                            <span class="font-weight-bold"><?php echo e($user->balance); ?>  <?php echo e(env('CURRENCY_TYPE')); ?></span>
                    </li>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                        Total Referral                            <span class="font-weight-bold">
                           <a href="javascript:void();"> <?php echo e($ru); ?> User</a>
                        </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Total Commissions                            <span class="font-weight-bold">
                           <a href="javascript:void();"> <?php echo e($rc); ?>  <?php echo e(env('CURRENCY_TYPE')); ?></a>
                        </span>
                    </li>
                                        </ul>
            </div>
        </div>
        <div class="card b-radius--10 overflow-hidden mt-30 box--shadow1">
            <div class="card-body">
                <h5 class="mb-20 text-muted">User action</h5>
                <a href="javascript:void();" route="<?php echo e(route('User.login.logs')); ?>" title="User log details" id="<?php echo e($user->id); ?>" class="btn btn--primary btn--shadow btn-block btn-lg getUserLog">
                    Login Logs                    </a>
                <a href="<?php echo e(route('send_email.users')); ?>/?id=<?php echo e(base64_encode($user->id)); ?>&name=<?php echo e(base64_encode($user->name)); ?>" class="btn btn--danger btn--shadow btn-block btn-lg">
                    Send Email                    </a>
                <form action="<?php echo e(route('account.user.delete')); ?>" method="post" class="mt-2">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($user->id); ?>" name="uid">
                    <button type="submit" class="btn btn--danger btn--shadow btn-block btn-lg"> Account delete </button>
                </form>
                
            </div>
        </div>
    </div>

    <div class="col-xl-9 col-lg-7 col-md-7 mb-30">

        <div class="row mb-none-30">
            <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--gradi-1 b-radius--10 box-shadow has--link">
                    <a href="<?php echo e(route('wallet.index')); ?>" class="item--link"></a>
                    <div class="icon">
                        <i class="fa fa-credit-card"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                            <span class="amount counter"><?php echo e($user->balance); ?></span>
                        </div>
                        <div class="desciption">
                            <span>My Ballance</span>
                        </div>
                    </div>
                </div>
            </div><!-- dashboard-w1 end -->
        
        
            <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--gradi-15 b-radius--10 box-shadow has--link">
                    <a href="<?php echo e(route('withdraw.index')); ?>" class="item--link"></a>
                    <div class="icon">
                        <i class="fa fa-wallet"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                            <span class="amount counter"><?php if($user->Account): ?> <?php echo e($user->Account->withdraw); ?> <?php else: ?> 0 <?php endif; ?> </span>
                            
                        </div>
                        <div class="desciption">
                            <span>Total Withdraw</span>
                        </div>
                    </div>
                </div>
            </div><!-- dashboard-w1 end -->
        <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--gradi-13 b-radius--10 box-shadow has--link">
                    <a href="javascript:void(0)" class="item--link"></a>
                    <div class="icon">
                        <i class="la la-exchange-alt"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount counter">
                                <?php echo e(count($user->UserAdsViewStatus)); ?>

                                
                            </span>
                        </div>
                        <div class="desciption">
                            <span>Total Ads views</span>
                        </div>
                    </div>
                </div>
            </div><!-- dashboard-w1 end -->
        <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
                <div class="dashboard-w1 bg--gradi-11 b-radius--10 box-shadow has--link">
                    <a <?php if(Auth::user()->Account): ?> data-fancybox="modal" data-src="#get_selected_plan_details" role="button" <?php else: ?> data-fancybox="modal" data-src="#create_membership_form" role="button" <?php endif; ?> href="javascript:void(0)" class="item--link"></a>
                    <div class="icon">
                        <i class="fa fa-tags"></i>
                    </div>
                    <div class="details">
                        <div class="numbers">
                            <span class="amount">
        
                                <?php if($user->Account): ?> <?php echo e(\App\Models\Membership::where('id',$user->Account->membership_id)->first()->name); ?> <?php else: ?> Setup plan <?php endif; ?>
                                
                            </span>
                        </div>
                        <div class="desciption">
                            <span>My plan</span>
                        </div>
                    </div>
                </div>
            </div><!-- dashboard-w1 end -->


        </div>


        <div class="card mt-50">
            <div class="card-body">
                <h5 class="card-title mb-50 border-bottom pb-2"><?php echo e($user->name); ?> Information</h5>

                <form action="<?php echo e(route('profile.update.ById')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($user->id); ?>" name="id">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">User Name <span class="text-danger">*</span></label>
                                <input class="form-control" type="text" name="name" value="<?php echo e($user->name); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">Email <span class="text-danger">*</span></label>
                                
                                <?php
                                    echo democheck('<input class="form-control" type="email" name="email" value="  [Email Protected For Demo]">',' <input class="form-control" type="email" name="email" value="'.$user->email.'">');
                                    
                                ?>
                                
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-control-label  font-weight-bold">Mobile Number <span class="text-danger">*</span></label>
                                <?php
                                    echo democheck('<input class="form-control" type="text" name="email" value="  [Phone Protected For Demo]">',' <input class="form-control" type="number" name="phone" value="'.$user->phone.'">');
                                    
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">Address </label>
                                <input class="form-control" type="text" name="address" value="<?php if($user->details): ?><?php echo e($user->details->address); ?><?php endif; ?>">
                                <small class="form-text text-muted"><i class="las la-info-circle"></i> House number,
                                    street address                                    </small>
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="form-group">
                                <label class="form-control-label font-weight-bold">City </label>
                                <input class="form-control" type="text" name="city" value="<?php if($user->details): ?><?php echo e($user->details->city); ?><?php endif; ?>">
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">State </label>
                                <input class="form-control" type="text" name="state" value="<?php if($user->details): ?><?php echo e($user->details->state); ?><?php endif; ?>">
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">Zip/Postal </label>
                                <input class="form-control" type="text" name="zip" value="<?php if($user->details): ?><?php echo e($user->details->zip); ?><?php endif; ?>">
                            </div>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <div class="form-group ">
                                <label class="form-control-label font-weight-bold">Country </label>
                                
                                <select name="country" class="form-control select2" style="width: 100%"> 
                                    <option value="Afghanistan"> Select Country</option>
                                    <?php $__currentLoopData = $contry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($contr->id); ?>" <?php if($user->details): ?> <?php if($user->details->country==$contr->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($contr->country); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="form-group col-xl-4 col-md-6  col-sm-3 col-12">
                            <label class="form-control-label font-weight-bold">Status </label>
                            
                            <input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger"
                                   data-toggle="toggle" data-on="Active" data-off="Banned" data-width="100%"
                                   name="status"
                                   <?php if($user->status!="on"): ?>
                                        
                                    <?php else: ?>
                                        checked
                                    <?php endif; ?> >
                        </div>

                        <div class="form-group  col-xl-4 col-md-6  col-sm-3 col-12">
                            <label class="form-control-label font-weight-bold">Email Verification </label>
                            <input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger"
                                   data-toggle="toggle" data-on="Verified" data-off="Unverified" name="ev"
                                   <?php if($user->email_verified_at==""  || $user->email_verified_at=="0000-00-00 00:00:00"): ?>
                                        
                                   <?php else: ?>
                                       checked
                                   <?php endif; ?> >

                        </div>

                        <div class="form-group  col-xl-4 col-md-6  col-sm-3 col-12">
                            <label class="form-control-label font-weight-bold">SMS Verification </label>
                            <input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger"
                                   data-toggle="toggle" data-on="Verified" data-off="Unverified" name="sv"
                                   <?php if($user->sms_verified_at=="" || $user->sms_verified_at=="0000-00-00 00:00:00"): ?>
                                        
                                   <?php else: ?>
                                       checked
                                   <?php endif; ?> >

                        </div>
                        
                    </div>


                    <div class="row mt-4">
                        <div class="col-md-12">
                            <div class="form-group">
                                <button type="submit" class="btn btn--primary btn-block btn-lg">Save Changes                                    </button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/users/users.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/users/details.blade.php ENDPATH**/ ?>