<footer class="footer">
    <span class="text-right">             
        Copyright <a target="_blank" href="#"><?php echo e(env('APP_NAME')); ?></a>
    </span>
    <span class="float-right">
        Powered by <a target="_blank" href="<?php echo e(route('home')); ?>" title="<?php echo e(env('APP_NAME')); ?>"><b><?php echo e(env('APP_NAME')); ?></b></a>
    </span>
</footer><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/extra/footer.blade.php ENDPATH**/ ?>