
<?php $__env->startSection('title'); ?>
    Your all transactions | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("PTC Ads",array("home","PTC","Ads","index"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-wallet"></i></h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Title</th>
                                <th>Credit</th>
                                <th>Debit</th>
                                <th>Final</th>
                                <th>Type</th>
                                <th>Short</th>
                                <th>Status</th>
                                <th>Time</th>
                                
                            </tr>
                        </thead>
                        <body>
                            <?php $__currentLoopData = $Transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($key+1)); ?></td>
                                    <td> <?php echo e($value->title); ?></td>
                                    <td>
                                        <?php if($value->credit==""): ?>
                                            
                                        <?php else: ?>
                                            <strong> <?php echo e(env('CURRENCY_TYPE')); ?>  <?php echo e($value->credit); ?></strong>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($value->debit==""): ?>
                                        <strong> <?php echo e(env('CURRENCY_TYPE')); ?>  0</strong>
                                        <?php else: ?>
                                            <strong> <?php echo e(env('CURRENCY_TYPE')); ?>  <?php echo e($value->debit); ?></strong>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong> <?php echo e(env('CURRENCY_TYPE')); ?>  <?php echo e($value->final); ?></strong></td>
                                    <td><?php echo e($value->type); ?></td>
                                    <td><?php echo e($value->description); ?></td>
                                    <td>
                                        <?php if($value->status=="on"): ?>
                                            <?= status("Active")?>
                                        <?php else: ?>
                                        <?= status("pending")?>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(Time_ago(strtotime($value->created_at))); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </body>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/index/transaction.blade.php ENDPATH**/ ?>