<div class="row">

    <div class="col-12">

        <div class="card mb-3">
            <div class="card-header">
                <h3>
                    <i class="fas fa-table"></i> Pricing table example 1</h3>
            </div>

            <div class="card-body">

                <div class="table-responsive">
                <table class="table table-condensed table-hover table-bordered table-responsive-sm">
                    <thead>
                        <tr>
                            <th class="tabco1" style="min-width:200px">PLAN</th>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="tabco2" style="min-width:200px"><?php echo e($item->name); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="tabco1">Price </td>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="tabco2">
                                    <?php echo e($item->price); ?> <?php echo e(env('CURRENCY_TYPE')); ?>

                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr>
                            <td class="tabco1">Daily limit</td>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="tabco2">
                                    <b><?php echo e($item->daily_limit); ?> PTC</b>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr>
                            <td class="tabco1">Referral Cmmission</td>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="tabco2">
                                    <b><?php echo e($item->referral_commission); ?> %</b>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr>
                            <td class="tabco1">Referral Cmmission</td>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="tabco2">
                                    <b><?php echo e($item->referral_commission); ?> %</b>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <tr>
                            <td class=""></td>
                            <?php $__currentLoopData = \App\Models\Membership::where('status','on')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="">
                                    <button data-fancybox="modal" data-src="#buy_premium<?php echo e($key); ?>" role="button"  class="btn btn-facebook" data-id="1">Subscribe Now</button>
                                </td>

                                
                                <div id="buy_premium<?php echo e($key); ?>" style="display: none; padding: 50px 5vw; max-width: 800px;text-align: center;">
                                    <h4>Buy Subscribe from <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($item->price); ?></h4>
            
                                    <p>This Subscriction no time limit to access but some function will be limited as per given item
                                    </p>
            
                                    <p>
                                        <form action="<?php echo e(route('trantransaction.pay')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="amount" value="<?php echo e($item->price); ?>">
                                            <input type="hidden" name="member_id" value="<?php echo e($item->id); ?>">
                                            <button type="submit" class="btn btn-success" role="button" >Confirm or pay <?php echo e(env('CURRENCY_TYPE')); ?> <?php echo e($item->price); ?></button>
                                        </form>
                                        
                                        <a data-fancybox-close class="btn btn-info" role="button" href="#">Cancel</a>
                                    </p>
            
                                    <p style="color: #aaa; font-size: 90%;">Simply click or pay get offer .</p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        
                    </tbody>
                </table>
                </div>
                
            </div>
            <!-- end card body -->

        </div>
        <!-- end card-->

    </div>
    <!-- end col-->
</div>
<?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/price_table/p1.blade.php ENDPATH**/ ?>