<?php
    echo $details['message'];
?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/mail/blank.blade.php ENDPATH**/ ?>