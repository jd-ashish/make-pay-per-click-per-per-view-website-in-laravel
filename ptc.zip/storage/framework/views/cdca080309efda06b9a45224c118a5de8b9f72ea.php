
<?php $__env->startSection('title'); ?>
    All user informations | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Users",array("home","Users","View"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-table"></i> Users</h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="" class="table table-bordered table-hover display getUser" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>name</th>
                                <th>email</th>
                                <th>phone</th>
                                <th>Role</th>
                                <th>Verifyed</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody class="users-resp">

                        </tbody>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/users/users.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/users/index.blade.php ENDPATH**/ ?>