
<?php $__env->startSection('title'); ?>
    PPC ads overview | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("PPC Ads overview",array("home","PPC","Ads","overview"),"")); ?>

<!-- end row -->



<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-table"></i> <a href="<?php echo e(route('ptc.newads')); ?>">Create New</a></h3>
            </div>

            <div class="card-body">
                <div class="table-responsive">
                    <table id="dataTable" class="table table-bordered table-hover display" style="width:100%">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Title</th>
                                <th>type</th>
                                <th>Duration</th>
                                <th>Maximum View</th>
                                <th>Viewed</th>
                                <th>Remain</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <body>
                            <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(($key+1)); ?></td>
                                    <td><?php echo e($ad->title); ?></td>
                                    <td>
                                        <?php switch($ad->type):
                                            case ('1'): ?>
                                                    <span class="font-weight-normal text--small badge badge-success"><i class="fa fa-link"></i> URL</span>
                                                <?php break; ?>
                                            <?php case ('2'): ?>
                                                    <span class="font-weight-normal text--small badge badge-success"><i class="fa fa-image"></i> Image</span>
                                                <?php break; ?>
                                            <?php case ('3'): ?>
                                                    <span class="font-weight-normal text--small badge badge-success"><i class="fa fa-code"></i> Code</span>
                                                <?php break; ?>
                                            <?php default: ?>
                                                
                                        <?php endswitch; ?></td>
                                    <td><?php echo e($ad->duration); ?> sec</td>
                                    <td><?php echo e($ad->max_show); ?></td>
                                    <td><?php echo e($ad->views); ?></td>
                                    <td><?php echo e(((int)$ad->max_show - (int)$ad->views)); ?></td>
                                    <td><?php echo e($ad->amount); ?> <?php echo e(env('CURRENCY_TYPE')); ?></td>
                                    <td><?php if($ad->status=="on"): ?>
                                        <?= status("Active")?>
                                    <?php else: ?>
                                        <?= status("Inactive")?>
                                    <?php endif; ?></td>
                                    <td class="btn-group"><a href="<?php echo e(route('ptc.edit',$ad->id)); ?>" class="icon-btn"><i class="fa fa-pencil-alt"></i></a> &nbsp; <a href="<?php echo e(route('ptc.destroy',$ad->id)); ?>" class="icon-btn-danger"><i class="fa fa-trash"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </body>
                    </table>
                </div>
                <!-- end table-responsive-->

            </div>
            <!-- end card-body-->

        </div>
        <!-- end card-->

    </div>

</div>
<!-- end row-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/users/users.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/ptc/index.blade.php ENDPATH**/ ?>