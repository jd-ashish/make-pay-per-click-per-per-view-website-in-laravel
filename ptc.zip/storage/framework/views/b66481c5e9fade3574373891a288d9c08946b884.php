<!-- Left Sidebar -->
<div class="left main-sidebar">

    <div class="sidebar-inner leftscroll">

        <div id="sidebar-menu">

            <ul>
                <li class="submenu">
                    <a class="active" href="<?php echo e(url('/')); ?>/home">
                        <i class="fas fa-bars"></i>
                        <span> Dashboard </span>
                    </a>
                </li>

                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a id="tables" href="#">
                            <i class="fas fa-user"></i>
                            <span> Manage users </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li class="submenu">
                                <a href="<?php echo e(route('users.index')); ?>">
                                    <span> Users </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('send_email.users')); ?>">Send email</a>
                            </li>
                        </ul>
                    </li>
                    
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a href="<?php echo e(route('refer.index')); ?>">
                            <i class="fas fa-tree"></i>
                            <span> Ref Commission </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a href="<?php echo e(route('ptc.index')); ?>">
                            <i class="fas fa-link"></i>
                            <span> PTC Ads </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a href="<?php echo e(route('membership.index')); ?>">
                            <i class="fas fa-tags"></i>
                            <span> Membership </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a id="tables" href="#">
                            <i class="fas fa-mail-bulk"></i>
                            <span> Email Manager </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li>
                                <a href="<?php echo e(route('email.config')); ?>">Email Config</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('email.global_template')); ?>">Global Template</a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li>
                        <a href="<?php echo e(route('sms.config')); ?>">
                            <i class="fas fa-sms"></i>
                            SMS Config
                        </a>
                    </li>
                <?php endif; ?>
                
                <?php if(Auth::user()->user_type=="user"): ?>
                    <li>
                        <a href="<?php echo e(route('MyAds.index')); ?>">
                            <i class="fas fa-tags"></i>
                            Ads
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('Transaction.index')); ?>">
                            <i class="fas fa-book"></i>
                            Transactions
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('wallet.index')); ?>">
                            <i class="fas fa-wallet"></i>
                            Wallet
                        </a>
                    </li>
                    <?php if(App\Models\Testimonials::where('user_id',Auth::user()->id)->first()): ?>
                    
                    <?php else: ?>
                        <li class="reate-us">
                            <a href="#" >
                                <i class="fas fa-wallet"></i>
                                RateUs
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="user"): ?>
                    <li class="submenu">
                        <a id="tables" href="#">
                            <i class="fas fa-mail-bulk"></i>
                            <span>Referral </span>
                            <span class="menu-arrow"></span>
                        </a>
                        <ul class="list-unstyled">
                            <li>
                                <a href="<?php echo e(route('Referral.commission')); ?>">Commission</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('Referral.user')); ?>">Refered user</a>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="user"): ?>
                <li class="submenu">
                    <a href="<?php echo e(route('withdraw.index')); ?>">
                        <i class="fas fa-tags"></i>
                        <span> Withdrawl now </span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a href="<?php echo e(route('faq.index')); ?>">
                            <i class="fas fa-tags"></i>
                            <span> FAQ </span>
                        </a>
                    </li>
                <?php endif; ?>
                <?php if(Auth::user()->user_type=="admin"): ?>
                    <li class="submenu">
                        <a href="<?php echo e(route('seo.index')); ?>">
                            <i class="fas fa-tags"></i>
                            <span> SEO </span>
                        </a>
                    </li>
                <?php endif; ?>
                

               

            </ul>

            <div class="clearfix"></div>

        </div>

        <div class="clearfix"></div>

    </div>

</div>
<!-- End Sidebar --><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/extra/left _sidebar.blade.php ENDPATH**/ ?>