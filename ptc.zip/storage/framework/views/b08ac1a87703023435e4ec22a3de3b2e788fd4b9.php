<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.css')); ?>" />
    <!-- BEGIN CSS for this page -->
    <link href="<?php echo e(asset('assets/css/pricing-tables.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- END CSS for this page -->
<?php $__env->stopSection(); ?>
<div class="row">
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-1 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('wallet.index')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-credit-card"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                    <span class="amount counter"><?php echo e(Auth::user()->balance); ?></span>
                </div>
                <div class="desciption">
                    <span>My Ballance</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->


    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-15 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('withdraw.index')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-wallet"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                    <span class="amount counter"><?php if(Auth::user()->Account): ?> <?php echo e(Auth::user()->Account->withdraw); ?> <?php else: ?> 0 <?php endif; ?> </span>
                    
                </div>
                <div class="desciption">
                    <span>Total Withdraw</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-25 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('withdraw.index')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-wallet"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"></span>
                    <span class="amount counter"><?php if(Auth::user()->Account): ?> <?php echo e(Auth::user()->Account->withdraw_count); ?> <?php else: ?> 0 <?php endif; ?> </span>
                    
                </div>
                <div class="desciption">
                    <span>Number of Withdraw</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-15 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('withdraw.request.pending')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-wallet"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                    <span class="amount counter">
                        <?php
                            $wiht = \App\Models\Withdraw::where('user_id',Auth::user()->id)->where('status','pending')->get();
                        ?>
                        <?php if($wiht): ?>
                            <?php
                                $amt_with = 0;
                                $c3 = 0;
                            ?>
                            <?php $__currentLoopData = $wiht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amt_with += $value->amount;
                                    $c3++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($amt_with); ?>

                        <?php endif; ?>
                    </span>
                    <span style="float:left; margin-left:-130px; margin-top:-30px; color:white">Total pending : <?php echo e($c3); ?></span>
                    
                </div>
                <div class="desciption">
                    <span>Withdraw pending</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-15 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('withdraw.request.denied')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-wallet"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                    <span class="amount counter">
                        <?php
                            $wiht = \App\Models\Withdraw::where('user_id',Auth::user()->id)->where('status','denied')->get();
                        ?>
                        <?php if($wiht): ?>
                            <?php
                                $amt_with = 0;
                                $c2 = 0;
                            ?>
                            <?php $__currentLoopData = $wiht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amt_with += $value->amount;
                                    $c2++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($amt_with); ?>

                        <?php endif; ?>
                    </span>
                    <span style="float:left; margin-left:-130px; margin-top:-30px; color:white">Total denied : <?php echo e($c2); ?></span>
                </div>
                <div class="desciption">
                    <span>Withdraw denied</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-16 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('withdraw.request.success')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-thumbs-up"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="currency-sign"><?php echo e(env('CURRENCY_TYPE')); ?></span>
                    <span class="amount counter">
                        <?php
                            $wiht = \App\Models\Withdraw::where('user_id',Auth::user()->id)->where('status','success')->get();
                        ?>
                        <?php if($wiht): ?>
                            <?php
                                $amt_with = 0;
                                $c4 = 0;
                            ?>
                            <?php $__currentLoopData = $wiht; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $amt_with += $value->amount;
                                    $c4++;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($amt_with); ?>

                        <?php endif; ?>
                    </span>
                    <span style="float:left; margin-left:-130px; margin-top:-30px; color:white">Total success : <?php echo e($c4); ?></span>
                </div>
                <div class="desciption">
                    <span>Withdraw success</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->

    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-21 b-radius--10 box-shadow has--link">
            <a href="<?php echo e(route('Transaction.index')); ?>" class="item--link"></a>
            <div class="icon">
                <i class="la la-exchange-alt"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="amount counter"><?php echo e(count(Auth::user()->Transaction)); ?></span>
                </div>
                <div class="desciption">
                    <span>Total Transaction</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->

    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-11 b-radius--10 box-shadow has--link">
            <a href="javascript:void(0)" class="item--link"></a>
            <div class="icon">
                <i class="la la-exchange-alt"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="amount counter">
                        <?php if(count(Auth::user()->Clicks)>0): ?>
                            <?php
                                $var = 0;
                            ?>
                            <?php $__currentLoopData = Auth::user()->Clicks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $var += $item->clicks;
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($var); ?>

                        <?php else: ?>
                            <?php echo e(count(Auth::user()->Clicks)); ?>

                        <?php endif; ?>
                        
                    </span>
                </div>
                <div class="desciption">
                    <span>Total Clicks</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-13 b-radius--10 box-shadow has--link">
            <a href="javascript:void(0)" class="item--link"></a>
            <div class="icon">
                <i class="la la-exchange-alt"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="amount counter">
                        <?php echo e(count(Auth::user()->UserAdsViewStatus)); ?>

                        
                    </span>
                </div>
                <div class="desciption">
                    <span>Total Ads views</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->

    <div class="col-xl-3 col-lg-6 col-sm-6 mb-30">
        <div class="dashboard-w1 bg--gradi-11 b-radius--10 box-shadow has--link">
            <a <?php if(Auth::user()->Account): ?> data-fancybox="modal" data-src="#get_selected_plan_details" role="button" <?php else: ?> data-fancybox="modal" data-src="#create_membership_form" role="button" <?php endif; ?> href="javascript:void(0)" class="item--link"></a>
            <div class="icon">
                <i class="fa fa-tags"></i>
            </div>
            <div class="details">
                <div class="numbers">
                    <span class="amount">

                        <?php if(Auth::user()->Account): ?> <?php echo e(\App\Models\Membership::where('id',Auth::user()->Account->membership_id)->first()->name); ?> <?php else: ?> Setup plan <?php endif; ?>
                        
                    </span>
                </div>
                <div class="desciption">
                    <span>My plan</span>
                </div>
            </div>
        </div>
    </div><!-- dashboard-w1 end -->
</div>
<!-- end row -->

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Track Today ads click views </h3>
            </div>

            <div class="card-body">
                <canvas id="today_ads" ></canvas>
                
            </div>
            <div class="card-footer small text-muted">Updated ever 5 to 15 sec</div>
        </div>
        <!-- end card-->
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="fas fa-chart-bar"></i> Withdrawl in <?php echo e(date('Y')); ?></h3>
            </div>

            <div class="card-body">
                <canvas id="with_drawl"></canvas>
            </div>
            <div class="card-footer small text-muted">Updated ever 5 to 15 sec</div>
        </div>
        <!-- end card-->
    </div>
</div>
<!-- end row -->
<?php
    $OS = \App\Models\UserLoginActivity::where('user_id',Auth::user()->id)->get();
    $os_name = array();
    $device_name = array();
    $browser_name = array();
?>
<?php $__currentLoopData = $OS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $os_name[] = json_decode($item->json)->getos;
    $device_name[] = json_decode($item->json)->getdevice;
    $browser_name[] = json_decode($item->json)->getbrowser;
?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php
    $k = array_keys(array_count_values($os_name));
    $v = array_values(array_count_values($os_name));

    $k1 = array_keys(array_count_values($device_name));
    $v1 = array_values(array_count_values($device_name));

    $k2 = array_keys(array_count_values($browser_name));
    $v2 = array_values(array_count_values($browser_name));
?>
<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
        
        <div class="card mb-3">
            <div class="card-header">
                <h3>Login via OS</h3>
            </div>

            <div class="card-body">
                <div id="OsLoginChart"></div>
            </div>
        </div>
        <!-- end card-->
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
        <div class="card mb-3">
            <div class="card-header">
                <h3>Login via browser</h3>
            </div>

            <div class="card-body">
                <div id="Browser"></div>
            </div>
        </div>
        <!-- end card-->
    </div>
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-6">
        <div class="card mb-3">
            <div class="card-header">
                <h3>Login via Device</h3>
            </div>

            <div class="card-body">
                <div id="Device"></div>
            </div>
        </div>
        <!-- end card-->
    </div>
</div>
<!-- end row -->



<div id="create_membership_form" style="display: none; padding: 40px ; max-width: 85%;">
    
    <?php switch(\App\Settings::where('var','price_table')->first()->val):
        case (1): ?>
                <?php echo $__env->make('admin.price_table.p1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case (2): ?>
                <?php echo $__env->make('admin.price_table.p2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
    <?php endswitch; ?>
    
</div>
<div id="get_selected_plan_details" style="display: none; padding: 40px ; max-width: 85%;">
    
    <?php switch(\App\Settings::where('var','price_table')->first()->val):
        case (1): ?>
                <?php echo $__env->make('admin.price_table.p1_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
        <?php case (2): ?>
                <?php echo $__env->make('admin.price_table.p2_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>
    <?php endswitch; ?>
    
</div>
<?php $__env->startSection('script'); ?>
<!-- BEGIN Java Script for this page -->
<script src="<?php echo e(asset('assets/plugins/fancybox/jquery.fancybox.min.js')); ?>"></script>
<!-- END Java Script for this page -->

<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<script>
    var key = [<?php echo '"'.implode('","', $k).'"' ?>];
    var value = [<?php echo implode(',', $v) ?>];

    var key1 = [<?php echo '"'.implode('","', $k1).'"' ?>];
    var value1 = [<?php echo implode(',', $v1) ?>];

    var key2 = [<?php echo '"'.implode('","', $k2).'"' ?>];
    var value2 = [<?php echo implode(',', $v2) ?>];

    var options = {
          series: value,
          chart: {
          width: 380,
          type: 'pie',
        },
        labels: key,
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };


        var chart = new ApexCharts(document.querySelector("#OsLoginChart"), options);
        chart.render();
      
      
      
        
        
        var options = {
          series: value2,
          chart: {
          width: 380,
          type: 'pie',
        },
        labels: key2,
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };


        var chart = new ApexCharts(document.querySelector("#Browser"), options);
        chart.render();

        var options = {
          series: value1,
          chart: {
          width: 380,
          type: 'pie',
        },
        labels: key1,
        responsive: [{
          breakpoint: 480,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };


        var chart = new ApexCharts(document.querySelector("#Device"), options);
        chart.render();
      
      
        
      
        
    </script>
<?php $__env->stopSection(); ?>

<?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/user_dash.blade.php ENDPATH**/ ?>