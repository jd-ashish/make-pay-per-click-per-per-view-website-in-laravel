<!-- top bar navigation -->
<div class="headerbar">

    <!-- LOGO -->
    <div class="headerbar-left">
        <a href="<?php echo e(route('home')); ?>" class="logo">
            <img alt="Logo" src="<?php echo e(url('/')); ?>/<?php echo e(setting_val('fevicon_thumbnail')); ?>" />
            <span><?php echo e(env('APP_NAME')); ?></span>
        </a>
    </div>

    <nav class="navbar-custom">

        <ul class="list-inline float-right mb-0">
            <li class="list-inline-item dropdown notif">
                <a class="nav-link dropdown-toggle arrow-none"href="<?php echo e(url('/')); ?>" >
                    <i class="fa fa-globe"></i>
                </a>

                

            </li>

            <li class="list-inline-item dropdown notif">
                <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" aria-haspopup="false" aria-expanded="false">
                    <i class="far fa-bell"></i>
                    <?php if(count(Auth::user()->Notification)<1): ?>
                        
                        <?php else: ?>
                        <?php if(count(\App\Notificaton::where('view',0)->get())>0): ?>
                            <span class="notif-bullet"></span>
                        <?php else: ?>
                            
                        <?php endif; ?>
                        
                    <?php endif; ?>
                    
                </a>

                <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-arrow-success dropdown-lg" >
                    <!-- item-->
                    <div class="dropdown-item noti-title">
                        <h5>
                            <small>
                                <span class="label label-danger pull-xs-right ntfy-cnt" nf-cnt="<?php echo e(count(Auth::user()->Notification)); ?>"><?php echo e(count(Auth::user()->Notification)); ?></span>Notification</small>
                        </h5>
                    </div>
                    
                    <div style="height: 300px; overflow-y: scroll">
                        <?php if(count(Auth::user()->Notification)<1): ?>
                            <a href="#" class="dropdown-item notify-item">
                                <h4>No any notification for you</h4>
                            </a>
                        <?php endif; ?>
                        <div class="sss">
                            <?php $__currentLoopData = Auth::user()->Notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="#" class="dropdown-item notify-item nofify-view  "   title="<?php echo e($value->title); ?>" id="<?php echo e($value->id); ?>" desc="<?php echo e($value->description); ?>" cat="<?php echo e(Time_ago(strtotime($value->created_at))); ?>">
                                <div class="notify-icon bg-faded">
                                    <?php if($value->type=="credit" || $value->type=="success"): ?>
                                        <img src="<?php echo e(asset('setting/success.gif')); ?>" alt="img" class="rounded img-fluid" >
                                    <?php else: ?>
                                        <img src="https://cdn1.iconfinder.com/data/icons/files-folders-vol-2/64/folder-error_2-512.png" alt="img" class="rounded img-fluid">
                                    <?php endif; ?>
                                    
                                </div>
                                <p class="notify-details" >
                                    <b class="<?php echo e($value->id); ?>" <?php if($value->view >0): ?> style="font-size:12px;" <?php else: ?> style="font-weight: bold; font-size:12px;" <?php endif; ?>><?php echo e($value->title); ?></b>
                                    <span class="<?php echo e($value->id); ?>b" <?php if($value->view >0): ?> style="font-size:12px;" <?php else: ?> style="font-weight: bold; font-size:12px;" <?php endif; ?>><?php echo e($value->description); ?></span>
                                    <small class="text-muted"><?php echo e(Time_ago(strtotime($value->created_at))); ?></small>
                                </p>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                    </div>

                    
                   

                    <!-- All-->
                    <a href="#" class="dropdown-item notify-item notify-all NotificationViewAll">
                        View All Allerts
                    </a>

                </div>
            </li>


            <?php if(Auth::user()->user_type=="admin"): ?>
                <li class="list-inline-item dropdown notif">
                    <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="#" aria-haspopup="false" aria-expanded="false">
                        <i class="fas fa-cog"></i>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right dropdown-arrow dropdown-arrow-success dropdown-sm">
                        <!-- item-->
                        <div class="dropdown-item noti-title">
                            <h5>
                                <small>Settings</small>
                            </h5>
                        </div>

                        <!-- item-->
                        <a href="<?php echo e(route('account.settings')); ?>" class="dropdown-item notify-item">
                            <p class="notify-details ml-0">
                                <i class="fas fa-cog"></i>
                                <b>Account settings</b>
                            </p>
                        </a>

                        <!-- item-->
                        <a href="<?php echo e(route('frontend.settings')); ?>" class="dropdown-item notify-item">
                            <p class="notify-details ml-0">
                                <i class="fas fa-cog"></i>
                                <b>frontend </b>
                            </p>
                        </a>

                    </div>

                </li>
            <?php endif; ?>
            


            <li class="list-inline-item dropdown notif">
                <a class="nav-link dropdown-toggle nav-user" data-toggle="dropdown" href="#" aria-haspopup="false" aria-expanded="false">
                    <img src="<?php if( Auth::user()->details): ?> <?php if(Auth::user()->details->avtar_image != ""): ?> <?php echo e(url('/')); ?>/<?php echo e(Auth::user()->details->avtar_image); ?> <?php else: ?> <?php echo e(asset('assets/images/avatars/admin.png')); ?> <?php endif; ?> <?php else: ?> <?php echo e(asset('assets/images/avatars/admin.png')); ?> <?php endif; ?>" alt="Profile image" class="avatar-rounded">
                </a>
                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                    <!-- item-->
                    <div class="dropdown-item noti-title">
                        <h5 class="text-overflow">
                            <small>Hello, <?php echo e(Auth::user()->name); ?></small>
                        </h5>
                    </div>

                    <!-- item-->
                    <a href="<?php echo e(route('profile')); ?>" class="dropdown-item notify-item">
                        <i class="fas fa-user"></i>
                        <span>Profile</span>
                    </a>

                    <!-- item-->
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item notify-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                        <i class="fas fa-power-off"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </li>

        </ul>

        <ul class="list-inline menu-left mb-0">
            <li class="float-left">
                <button class="button-menu-mobile open-left">
                    <i class="fas fa-bars"></i>
                </button>
            </li>
        </ul>

    </nav>

</div>
<!-- End Navigation -->
<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/extra/top_bar.blade.php ENDPATH**/ ?>