<?php if($message = Session::get('success')): ?>
<script type="text/javascript">
    $(document).ready(function(){
        iziToast['success']({
                    message: "<?php echo e($message); ?>",
                    position: "topRight"
                });
    });
</script>
<?php endif; ?>
  
<?php if($message = Session::get('error')): ?>
<script type="text/javascript">
    $(document).ready(function(){
        iziToast['error']({
                    message: "<?php echo e($message); ?>",
                    position: "topRight"
                });
    });
</script>
<?php endif; ?>
   
<?php if($message = Session::get('warning')): ?>
<script type="text/javascript">
    $(document).ready(function(){
        iziToast['warning']({
                    message: "<?php echo e($message); ?>",
                    position: "topRight"
                });
    });
</script>
<?php endif; ?>
   
<?php if($message = Session::get('info')): ?>
<script type="text/javascript">
    $(document).ready(function(){
        iziToast['info']({
                    message: "<?php echo e($message); ?>",
                    position: "topRight"
                });
    });
</script>
<?php endif; ?>
  
<?php if($errors->any()): ?>
<script type="text/javascript">
    $(document).ready(function(){
        iziToast['error']({
                    message: "Please check the form below for errors",
                    position: "topRight"
                });
    });
</script>
<?php endif; ?>

<?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/message.blade.php ENDPATH**/ ?>