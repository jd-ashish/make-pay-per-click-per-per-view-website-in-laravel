

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/trumbowyg/ui/trumbowyg.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
<?php if(isset($_GET['id'])): ?>
    Send email to <?php echo e(base64_decode($_GET['name'])); ?> | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php else: ?>
    Send email to All users | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo e(top_brade("Send email to users",array("home","dashbord","users","Send email to users","index"),"")); ?>

<!-- end row -->

<?php if(isset($_GET['id'])): ?>
<?php echo e(back_link(route('user.details',base64_decode($_GET['id'])))); ?>

<?php else: ?>
<?php echo e(back_link(route('users.index'))); ?>

<?php endif; ?>


<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
        <div class="card mb-3">
            <div class="card-header">
                <h3><i class="far fa-file"></i> Send email to <?php if(isset($_GET['name'])): ?> <?php echo e(base64_decode($_GET['name'])); ?> <?php else: ?> all users <?php endif; ?></h3>
            </div>
            <form action="<?php echo e(route('send.email.users')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php if(isset($_GET['id'])): ?>
                <input type="hidden" name="user_id" value="<?php echo e(base64_decode($_GET['id'])); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <input type="text" name="subjects" class="form-control" placeholder="Enter subjects ">
                </div>
                
                
                <div class="card-body">
                    <textarea rows="3" class="form-control editor" name="messages" placeholder="Enter messages"></textarea>
                </div>
                <button class="btn btn-dropbox float-right" type="submit">Send id</button>
            </form>
            
        </div><!-- end card-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('assets/plugins/trumbowyg/trumbowyg.min.js')); ?>"></script>
<script>
    $(document).on('ready',function() {
        'use strict';
        $('.editor').trumbowyg();
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/users/send_email.blade.php ENDPATH**/ ?>