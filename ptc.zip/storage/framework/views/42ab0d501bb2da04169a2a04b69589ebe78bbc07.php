<style>
    


[style*="--aspect-ratio"] > :first-child {
  width: 100%;
}
[style*="--aspect-ratio"] > img {  
  height: auto;
} 
@supports (--custom:property) {
  [style*="--aspect-ratio"] {
    position: relative;
  }
  [style*="--aspect-ratio"]::before {
    content: "";
    display: block;
    padding-bottom: calc(100% / (var(--aspect-ratio)));
  }  
  [style*="--aspect-ratio"] > :first-child {
    position: absolute;
    top: 0;
    left: 0;
    height: 100%;
  }  
}

body {
  margin: 0;
  padding: 0;
  font-family: "Lato", sans-serif;
  font-size: 20pt;
  font-weight: normal;
  background: lightblue; /* For browsers that do not support gradients */
  background: -webkit-linear-gradient(
    -90deg,
    orange,
    red
  ); /* For Safari 5.1 to 6.0 */
  background: -o-linear-gradient(
    -90deg,
    orange,
    red
  ); /* For Opera 11.1 to 12.0 */
  background: -moz-linear-gradient(
    -90deg,
    orange,
    red
  ); /* For Firefox 3.6 to 15 */
  background: linear-gradient(-90deg, orange, red); /* Standard syntax */
}

.main {
  margin: 100px auto;
  text-align: center;
  color:white;
}

button {
  padding: 20px;
  background: transparent;
  text-shadow: 1px 1px 1px #202020;
  font-family: "Lato", sans-serif;
  font-size: 18pt;
  border: 1px solid lightblue;
  color: lightblue;
}

</style>



<?php $__env->startSection('title'); ?>
    Ads view sections | <?php echo e(env('APP_NAME',setting_val('APP_NAME'))); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<?php switch($ads->type):
    case (1): ?>
        <html>

<head>
  <meta charset="UTF-8">
  <title></title>
  <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
</head>

<body>
  <div class="main">

    <h3>Don't close or refresh page until Ads load or finish</h3>
    <button id="counter"></button>

    <h5 class="mt-5">note : Bee patient everythings automatic Don't ever try to close any windows other wise you will not able to earn</h5>

  </div>
</body>

</html>

<form method="post" id="sbmit" action="<?php echo e(route('ptc.ern')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="<?php echo e($ads->id); ?>" name="adid" >
</form>
<form method="post" id="fail" action="<?php echo e(route('ptc.fail')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" value="You have not earn due to miss timeing" name="fail" >
</form>


    <script>
        function openChecking(){
            // alert("open");
            var width = Number(screen.width-(screen.width*0.25));  
            var height = Number(screen.height-(screen.height*0.25));
            var leftscr = Number((screen.width/2)-(width/2)); // center the window
            var topscr = Number((screen.height/2)-(height/2));
            var url = "<?php echo e($ads->type_data); ?>";
            var title = 'popup';
            var properties = 'width='+width+', height='+height+', top='+topscr+', left='+leftscr;
            var popup = window.open(url, title, properties);
            var crono = window.setInterval(function() {
                if (popup.closed !== false) { // !== opera compatibility reasons
                    window.clearInterval(crono);
                    checkClosed();
                }
                console.log(popup.blur());


                count_ads = 0;
                function iin(limit_ads) {
                count_ads += 1;
                if(count_ads>=limit_ads){
                    // document.getElementById("counter").innerHTML = "Click me not: " + count;
                    // openChecking();
                }else{
                    document.getElementById("counter").innerHTML = "Ads Open with in : " + count_ads;
                }
                if(count_ads==limit_ads){
                    // document.getElementById("counter").innerHTML = "Click me not: " + count;
                    popup.close();
                     if (popup.closed !== false) { // !== opera compatibility reasons
                        window.clearInterval(crono);
                        console.log('Time up')
                        //user win
                        document.getElementById('sbmit').submit(); 
                    }
                }
                if(count_ads<limit_ads){
                    // document.getElementById("counter").innerHTML = "Click me not: " + count;
                     if (popup.closed !== false) { // !== opera compatibility reasons
                        window.clearInterval(crono);
                        console.log('Time down')
                        document.getElementById('fail').submit(); 
                    }
                }
                
                };
                setInterval(function(){ iin("<?php echo e($ads->duration); ?>") }, 1000);




            }, 250); //we check if the window is closed every 1/4 second
        }   
        function checkClosed(){
            window.onbeforeunload = function() {
                if (data_needs_saving()) {
                    return "Do you really want to leave our brilliant application?";
                } else {
                    return;
                }
            };
            console.log('Time down');//User faild to win user loos
        }



        window.onbeforeunload = function() {
                if (data_needs_saving()) {
                    return "Do you really want to leave our brilliant application?";
                } else {
                    return "noooo";
                }
            };
    </script>    



<script>
// var button = document.getElementById("clickme"),
  count = 0;
function incre(limit) {
  count += 1;
  if(count>=limit){
    // document.getElementById("counter").innerHTML = "Click me not: " + count;
    // openChecking();
  }else{
    document.getElementById("counter").innerHTML = "Ads Open with in : " + count;
  }
  if(count==limit){
    // document.getElementById("counter").innerHTML = "Click me not: " + count;
    openChecking();
  }
  
};
setInterval(function(){ incre(3) }, 1000);
</script>
        <?php break; ?>
    <?php case (2): ?>
    <div class="main" style="margin-top: -10px">
        <div class="container">          
            <img src="<?php echo e(url('/')); ?>/images/<?php echo e($ads->type_data); ?>" class="rounded" alt="Cinque Terre" width="400" height="296"> 
          </div>
        <h3>Don't close or refresh page until Ads load or finish</h3>
        <button id="txt"></button>
    
        <h5 class="mt-5">note : Bee patient everythings automatic Don't ever try to close any windows other wise you will not able to earn</h5>
    
      </div>
    
    
      

      

        <form method="post" id="sbmit2" action="<?php echo e(route('ptc.ern')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($ads->id); ?>" name="adid" >
        </form>

          <script>

startCount();



            var c = 0;
            var t;
            var timer_is_on = 0;
            
            function timedCount() {
              document.getElementById("txt").innerHTML = c+" Wait Up to "+"<?php echo e($ads->duration); ?> second";
              c = c + 1;
              if(c=="<?php echo e($ads->duration); ?>"){
                  document.getElementById('sbmit2').submit(); 
              }
              t = setTimeout(timedCount, 1000);
            }
            
            function startCount() {
              if (!timer_is_on) {
                timer_is_on = 1;
                timedCount();
              }
            }
            
            function stopCount() {
              clearTimeout(t);
              timer_is_on = 0;
            }
          </script>
        <?php break; ?>
        <?php case (3): ?>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>



<div class="main" style="margin-top: -10px">
    <div id = "CompTwo">
        <div id="click" onclick="click()">
            <?= $ads->type_data?>
          </div>
    </div>
    <h3>Don't close or refresh page until Ads load or finish</h3>
    <button id="txt"></button>

    <h5 class="mt-5">note : Bee patient everythings automatic Don't ever try to close any windows other wise you will not able to earn</h5>
    <div id = "CompTwo">
        <div id="click" onclick="click()">
            <?= $ads->type_data?>
          </div>
    </div>
    <div id = "CompTwo">
        <div id="click" onclick="click()">
            <?= $ads->type_data?>
          </div>
    </div>
  </div>
          
          <form method="post" id="sbmit2" action="<?php echo e(route('ptc.ern')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" value="<?php echo e($ads->id); ?>" name="adid" >
        </form>

          <script>

startCount();



            var c = 0;
            var t;
            var timer_is_on = 0;
            
            function timedCount() {
              document.getElementById("txt").innerHTML = c+" Wait Up to "+"<?php echo e($ads->duration); ?> second";
              c = c + 1;
              if(c=="<?php echo e($ads->duration); ?>"){
                  document.getElementById('sbmit2').submit(); 
              }
              t = setTimeout(timedCount, 1000);
            }
            
            function startCount() {
              if (!timer_is_on) {
                timer_is_on = 1;
                timedCount();
              }
            }
            
            function stopCount() {
              clearTimeout(t);
              timer_is_on = 0;
            }
          </script>
        <?php break; ?>
    <?php default: ?>
    <?php echo e($ads->type_data); ?>

<?php endswitch; ?>



<!-- HTML -->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/ptc/users/viewads.blade.php ENDPATH**/ ?>