<div class="table-responsive">
    <?php
        // print_r($user);
    ?>
    <table id="" class="table table-bordered table-hover display getUser" style="width:100%">
        <thead>
            <tr>
                <th>id</th>
                <th>IP</th>
                <th>Device</th>
                <th>browser</th>
                <th>OS</th>
                <th>created</th>
                <th>status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $arr = json_decode($value->login_log);
                ?>
                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>#<?php echo e(($k+1)); ?></td>
                        <td><?php echo e(json_decode($item->json)->ip); ?></td>
                        <td><?php echo e(json_decode($item->json)->getbrowser); ?></td>
                        <td><?php echo e(json_decode($item->json)->getdevice); ?></td>
                        <td><?php echo e(json_decode($item->json)->getos); ?></td>
                        <td><?php echo e(Time_ago(strtotime($item->created_at))); ?></td>
                        <td><?php echo e($item->status); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div><?php /**PATH G:\Database\htdocs\pro\ptc\resources\views/admin/table/login_log_table.blade.php ENDPATH**/ ?>