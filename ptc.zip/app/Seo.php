<?php


namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Seo extends Model
{
    protected $table = "seo_settings";

    
}
